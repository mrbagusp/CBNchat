'use client'

import { X, Gift } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAppStore, useActiveWorkspace } from '@/lib/store'

export function TrialBanner() {
  const trialBannerDismissed = useAppStore((s) => s.trialBannerDismissed)
  const dismissTrialBanner = useAppStore((s) => s.dismissTrialBanner)
  const workspace = useActiveWorkspace()

  if (trialBannerDismissed) return null

  // Compute days remaining from workspace trial_ends_at
  let daysLeft = 3
  let trialEndLabel = 'April 19, 2026'
  if (workspace?.trial_ends_at) {
    const end = new Date(workspace.trial_ends_at)
    daysLeft = Math.max(0, Math.ceil((end.getTime() - Date.now()) / 86_400_000))
    trialEndLabel = end.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
  }

  return (
    <div className="bg-gradient-to-r from-teal-50 to-teal-100 border border-teal-200 rounded-xl p-4 flex items-center gap-4 mb-6">
      {/* Icon */}
      <div className="w-9 h-9 rounded-lg bg-teal-600 flex items-center justify-center flex-shrink-0">
        <Gift className="w-4 h-4 text-white" />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5 flex-wrap">
          <Badge className="bg-amber-100 text-amber-700 border-0 text-[10px] font-bold uppercase tracking-wide hover:bg-amber-100">
            PRO PLAN TRIAL
          </Badge>
          <span className="text-sm font-semibold text-slate-800">
            {daysLeft} {daysLeft === 1 ? 'day' : 'days'} left of your trial
          </span>
        </div>
        <p className="text-xs text-slate-600">
          Enjoying premium features. Reverts to Free plan in {daysLeft} {daysLeft === 1 ? 'day' : 'days'} on {trialEndLabel}.
        </p>
      </div>

      {/* CTA */}
      <Button
        size="sm"
        className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-xs px-4 flex-shrink-0"
      >
        Show Plans
      </Button>

      {/* Dismiss */}
      <button
        onClick={dismissTrialBanner}
        className="w-7 h-7 rounded-lg flex items-center justify-center text-teal-600 hover:bg-teal-200 transition-colors flex-shrink-0"
        aria-label="Dismiss trial banner"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  )
}
