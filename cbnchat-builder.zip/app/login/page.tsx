'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Instagram, Mail, Shield, Globe, MessageCircle, ArrowLeft, Rocket } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { useAppStore } from '@/lib/store'
import { DEMO_PROFILE } from '@/lib/mock-data'
// Facebook icon — inline SVG to match brand blue exactly
function FacebookIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073C24 5.404 18.627 0 12 0S0 5.404 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z" />
    </svg>
  )
}

export default function LoginPage() {
  const router = useRouter()
  const login = useAppStore((s) => s.login)

  function handleDemoLogin() {
    // TODO(Phase 4): Replace with real Supabase Auth before production deploy
    login(DEMO_PROFILE)
    router.push('/app/home')
  }

  function handleInstagramClick() {
    // TODO(Phase 4): Replace with real Instagram OAuth redirect
    toast.info('OAuth flow activates in Phase 4', {
      description: 'Use the demo button below to explore the app now.',
    })
  }

  function handleEmailClick() {
    // TODO(Phase 4): Replace with real Supabase email/password sign-in
    toast.info('Email auth activates in Phase 4', {
      description: 'Use the demo button below to explore the app now.',
    })
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 font-sans">
      {/* Back to home */}
      <Link
        href="/"
        className="absolute top-6 left-6 flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </Link>

      {/* Card */}
      <div className="w-full max-w-[440px] bg-white rounded-2xl border border-slate-200 shadow-sm p-8">

        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-xl bg-teal-700 flex items-center justify-center shadow-sm">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-slate-900 text-xl tracking-tight">CBNchat</span>
        </div>

        {/* Heading */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Welcome to CBNchat 👋
          </h1>
          <p className="text-sm text-slate-600 mt-1.5">Login to your CBNchat account</p>
        </div>

        {/* Primary: Instagram button */}
        <button
          onClick={handleInstagramClick}
          className="btn-instagram w-full h-12 flex items-center justify-center gap-2.5 rounded-lg font-semibold text-sm shadow-sm"
        >
          <Instagram className="w-4 h-4" />
          Continue with Instagram
        </button>

        {/* Trust microcopy */}
        <p className="text-center text-xs text-slate-500 mt-2.5 flex items-center justify-center gap-1.5">
          <Shield className="w-3 h-3" />
          Secured via official Instagram Login API — Meta Tech Partner
        </p>

        {/* Facebook — disabled, Phase 7 */}
        <TooltipProvider delayDuration={100}>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="w-full mt-3">
                <button
                  disabled
                  aria-disabled="true"
                  className="w-full h-12 flex items-center justify-center gap-2.5 rounded-lg font-semibold text-sm bg-[#1877F2] text-white opacity-50 cursor-not-allowed"
                >
                  <FacebookIcon className="w-4 h-4" />
                  Continue with Facebook
                </button>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              Coming in Phase 7 — Facebook Page support
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {/* Divider */}
        <div className="flex items-center gap-3 my-5">
          <Separator className="flex-1" />
          <span className="text-xs text-slate-400 font-medium">or</span>
          <Separator className="flex-1" />
        </div>

        {/* Tertiary: Email */}
        <Button
          variant="outline"
          className="w-full h-11 border-slate-200 text-slate-700 rounded-lg text-sm font-medium"
          onClick={handleEmailClick}
        >
          <Mail className="w-4 h-4 mr-2" />
          Continue with Email
        </Button>

        {/* Sign up link */}
        <p className="text-center text-xs text-slate-500 mt-4">
          Don&apos;t have an account?{' '}
          <Link href="/signup" className="text-teal-700 font-medium hover:underline">
            Sign up
          </Link>
        </p>

        {/* Meta badge */}
        <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <Globe className="w-3 h-3" />
            Meta Tech Provider
          </span>
          <a href="mailto:support@cbnchat.id" className="hover:text-slate-600 transition-colors">
            Contact Support
          </a>
        </div>
      </div>

      {/* Amber demo button — prominent, below card */}
      <div className="mt-4 w-full max-w-[440px]">
        <button
          onClick={handleDemoLogin}
          className="w-full h-12 flex items-center justify-center gap-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-white font-semibold text-sm shadow-sm transition-colors"
        >
          <Rocket className="w-4 h-4" aria-hidden="true" />
          Enter Demo Workspace
        </button>
        <p className="text-center text-[11px] text-slate-400 mt-1.5">
          No account needed. Explore with pre-loaded demo data.
        </p>
      </div>

      <p className="mt-5 text-xs text-slate-400 text-center max-w-xs leading-relaxed">
        By continuing, you agree to our{' '}
        <Link href="/terms" className="underline hover:text-slate-600">Terms</Link>
        {' '}and{' '}
        <Link href="/privacy" className="underline hover:text-slate-600">Privacy Policy</Link>.
      </p>
    </div>
  )
}
