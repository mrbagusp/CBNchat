import Link from 'next/link'
import { CheckCircle2, MessageCircle } from 'lucide-react'

export async function generateMetadata({ params }: { params: Promise<{ code: string }> }) {
  await params
  return {
    title: 'Data Deletion Status — CBNchat',
    description: 'Status of your data deletion request',
  }
}

export default async function DeletionStatusPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 font-sans">
      {/* Logo */}
      <div className="flex items-center gap-2 mb-10">
        <div className="w-8 h-8 rounded-lg bg-teal-700 flex items-center justify-center">
          <MessageCircle className="w-4 h-4 text-white" />
        </div>
        <span className="font-bold text-slate-900 text-lg tracking-tight">CBNchat</span>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 max-w-md w-full text-center">
        <div className="w-14 h-14 rounded-full bg-teal-50 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 className="w-7 h-7 text-teal-600" />
        </div>

        <h1 className="text-xl font-bold text-slate-900 mb-2">
          Data Deletion Request Received
        </h1>
        <p className="text-slate-600 text-sm leading-relaxed mb-6">
          Your data deletion request is being processed. All personal data associated
          with your CBNchat account will be removed within 30 days, in accordance with
          our Privacy Policy and Meta Platform policies.
        </p>

        <div className="bg-slate-50 rounded-xl border border-slate-200 px-4 py-3 mb-6 text-left">
          <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mb-1">
            Confirmation Code
          </p>
          <code className="text-sm font-mono font-bold text-slate-900">{code}</code>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed mb-5">
          Please save this confirmation code for your records. If you have questions,
          contact us at{' '}
          <a href="mailto:support@cbnchat.id" className="text-teal-700 underline">
            support@cbnchat.id
          </a>
          .
        </p>

        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-teal-700 font-medium hover:underline"
        >
          Return to CBNchat home
        </Link>
      </div>
    </div>
  )
}
