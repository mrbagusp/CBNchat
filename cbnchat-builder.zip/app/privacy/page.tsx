import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export const metadata = {
  title: 'Privacy Policy — CBNchat',
  description: 'How CBNchat collects, uses, and protects your data.',
}

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-10 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to home
        </Link>

        <h1 className="text-4xl font-bold text-slate-900 tracking-tight mb-2">Privacy Policy</h1>
        <p className="text-slate-500 mb-12">Last updated: 16 April 2026</p>

        <div className="prose prose-slate max-w-none space-y-8">
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">1. Who We Are</h2>
            <p className="text-slate-600 leading-relaxed">
              CBNchat is a social media automation platform operated by CBN Indonesia
              (&ldquo;we&rdquo;, &ldquo;us&rdquo;, &ldquo;our&rdquo;). This Privacy Policy explains
              how we collect, use, and protect information when you use our service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">2. Data We Collect</h2>
            <p className="text-slate-600 leading-relaxed mb-3">We collect the following types of data:</p>
            <ul className="list-disc pl-6 space-y-2 text-slate-600">
              <li><strong>Account data:</strong> name, email address, profile picture from your Meta account.</li>
              <li><strong>Instagram/Facebook data:</strong> page and account information, follower count, media metadata — accessed via official Meta Graph API.</li>
              <li><strong>Contact data:</strong> Instagram usernames and user IDs of followers who interact with your posts, collected only after you trigger an automation.</li>
              <li><strong>Usage data:</strong> which features you use, automation run logs, error logs — used for service improvement.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">3. How We Use Your Data</h2>
            <ul className="list-disc pl-6 space-y-2 text-slate-600">
              <li>To provide, operate, and improve the CBNchat service.</li>
              <li>To send automated DMs and replies on your behalf as configured in your automations.</li>
              <li>To push contact records to your CRM via outbound webhooks you configure.</li>
              <li>To communicate important service updates and security notices.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">4. Meta Platform Data</h2>
            <p className="text-slate-600 leading-relaxed">
              CBNchat uses the Meta (Facebook/Instagram) Login API and Webhooks API. We access
              only the permissions you explicitly grant during OAuth. We do not sell or share
              Meta user data with third parties, except as required by your own CRM webhook
              configurations. Data received from Meta is handled in accordance with
              Meta&apos;s Platform Terms.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">5. Data Deletion</h2>
            <p className="text-slate-600 leading-relaxed">
              You can request deletion of all your data at any time by emailing{' '}
              <a href="mailto:support@cbnchat.local" className="text-teal-700 underline">
                support@cbnchat.local
              </a>
              . Meta users can also trigger deletion via the{' '}
              <strong>Data Deletion Callback</strong> at{' '}
              <code className="bg-slate-100 px-1.5 py-0.5 rounded text-xs">
                /api/meta/data-deletion
              </code>
              , which is required by Meta&apos;s platform policies.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">6. Data Retention</h2>
            <p className="text-slate-600 leading-relaxed">
              Contact records are retained until you delete them or disconnect your account.
              Automation run logs are retained for 90 days. Account data is deleted within 30 days
              of account closure.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">7. Security</h2>
            <p className="text-slate-600 leading-relaxed">
              All data is stored in encrypted databases. Webhook payloads are signed with
              HMAC-SHA256. Access tokens are stored encrypted at rest. We follow OWASP security
              best practices throughout our codebase.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">8. Contact</h2>
            <p className="text-slate-600 leading-relaxed">
              For privacy questions or data requests, contact us at{' '}
              <a href="mailto:support@cbnchat.local" className="text-teal-700 underline">
                support@cbnchat.local
              </a>
              .
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
