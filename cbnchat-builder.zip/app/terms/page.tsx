import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export const metadata = {
  title: 'Terms of Service — CBNchat',
  description: 'Terms governing your use of CBNchat.',
}

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-10 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to home
        </Link>

        <h1 className="text-4xl font-bold text-slate-900 tracking-tight mb-2">Terms of Service</h1>
        <p className="text-slate-500 mb-12">Last updated: 16 April 2026</p>

        <div className="space-y-8">
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">1. Acceptance of Terms</h2>
            <p className="text-slate-600 leading-relaxed">
              By accessing or using CBNchat, you agree to be bound by these Terms of Service and our
              Privacy Policy. If you disagree with any part of these terms, you may not use the service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">2. Permitted Use</h2>
            <p className="text-slate-600 leading-relaxed mb-3">You may use CBNchat to:</p>
            <ul className="list-disc pl-6 space-y-2 text-slate-600">
              <li>Automate Instagram and Facebook comment/DM responses for accounts you own or manage.</li>
              <li>Capture contact data from your own audience with appropriate consent.</li>
              <li>Forward contact data to your own CRM systems via webhooks.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">3. Prohibited Use</h2>
            <p className="text-slate-600 leading-relaxed mb-3">You must NOT:</p>
            <ul className="list-disc pl-6 space-y-2 text-slate-600">
              <li>Use CBNchat to send spam, misleading messages, or content that violates Meta&apos;s Community Standards.</li>
              <li>Automate accounts you do not own or have explicit permission to manage.</li>
              <li>Attempt to reverse-engineer, scrape, or exploit the service or Meta APIs through CBNchat.</li>
              <li>Use the service in a way that violates any applicable law or Meta Platform Terms.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">4. Meta Platform Compliance</h2>
            <p className="text-slate-600 leading-relaxed">
              CBNchat operates as a Meta Tech Provider. Your use of Instagram and Facebook features
              through CBNchat is subject to Meta&apos;s Platform Terms and Policies. We may suspend
              your access if your usage violates Meta&apos;s policies.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">5. Service Availability</h2>
            <p className="text-slate-600 leading-relaxed">
              CBNchat is provided &ldquo;as is&rdquo; without warranty of uptime or availability.
              We strive for high availability but cannot guarantee uninterrupted service. We are
              not liable for any losses resulting from service downtime or Meta API changes.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">6. Account Termination</h2>
            <p className="text-slate-600 leading-relaxed">
              We reserve the right to suspend or terminate accounts that violate these Terms,
              Meta policies, or applicable law. You may cancel your account at any time.
              Upon cancellation, your data will be deleted per our Privacy Policy.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">7. Changes to Terms</h2>
            <p className="text-slate-600 leading-relaxed">
              We may update these Terms from time to time. Continued use of CBNchat after
              changes constitutes acceptance of the updated Terms. Material changes will be
              communicated via email.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-3">8. Contact</h2>
            <p className="text-slate-600 leading-relaxed">
              Questions about these Terms?{' '}
              <a href="mailto:support@cbnchat.local" className="text-teal-700 underline">
                support@cbnchat.local
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
