'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Instagram, Mail, Shield, Globe, MessageCircle, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'
import { DEMO_PROFILE } from '@/lib/mock-data'

export default function SignupPage() {
  const router = useRouter()
  const login = useAppStore((s) => s.login)
  const [showEmail, setShowEmail] = useState(false)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  function handleEmailSignup(e: React.FormEvent) {
    e.preventDefault()
    // NOTE: Phase 4 will wire this to Supabase Auth. Preview logs in as demo.
    login(DEMO_PROFILE)
    router.push('/app/home')
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 font-sans">
      <Link
        href="/"
        className="absolute top-6 left-6 flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </Link>

      <div className="w-full max-w-sm bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-xl bg-teal-700 flex items-center justify-center shadow-sm">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-slate-900 text-xl tracking-tight">CBNchat</span>
        </div>

        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Create your account</h1>
          <p className="text-sm text-slate-500 mt-1.5">Start automating in minutes</p>
        </div>

        <a
          href="/api/auth/instagram/start"
          className="btn-instagram w-full flex items-center justify-center gap-2.5 py-3 px-4 rounded-lg font-semibold text-sm shadow-sm"
        >
          <Instagram className="w-4 h-4" />
          Continue with Instagram
        </a>

        <p className="text-center text-xs text-slate-400 mt-3 flex items-center justify-center gap-1">
          <Shield className="w-3 h-3" />
          Secured login using official Instagram API
        </p>

        <div className="flex items-center gap-3 my-5">
          <Separator className="flex-1" />
          <span className="text-xs text-slate-400 font-medium">or</span>
          <Separator className="flex-1" />
        </div>

        {!showEmail ? (
          <Button
            variant="outline"
            className="w-full border-slate-200 text-slate-700 rounded-lg h-10 text-sm font-medium"
            onClick={() => setShowEmail(true)}
          >
            <Mail className="w-4 h-4 mr-2" />
            Continue with Email
          </Button>
        ) : (
          <form onSubmit={handleEmailSignup} className="space-y-3">
            <div>
              <Label htmlFor="name" className="text-xs text-slate-600 font-medium">Full Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="mt-1 h-9 text-sm rounded-lg border-slate-200"
                required
              />
            </div>
            <div>
              <Label htmlFor="email" className="text-xs text-slate-600 font-medium">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="mt-1 h-9 text-sm rounded-lg border-slate-200"
                required
              />
            </div>
            <div>
              <Label htmlFor="password" className="text-xs text-slate-600 font-medium">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min. 8 characters"
                className="mt-1 h-9 text-sm rounded-lg border-slate-200"
                required
                minLength={8}
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-teal-700 hover:bg-teal-800 text-white rounded-lg h-9 text-sm"
            >
              Create Account
            </Button>
          </form>
        )}

        <div className="text-center mt-5 space-y-2">
          <p className="text-xs text-slate-500">
            Already have an account?{' '}
            <Link href="/login" className="text-teal-700 font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </div>

        <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <Globe className="w-3 h-3" />
            Meta Tech Provider
          </span>
          <a href="mailto:support@cbnchat.local" className="hover:text-slate-600 transition-colors">
            Contact Support
          </a>
        </div>
      </div>

      <p className="mt-6 text-xs text-slate-400 text-center max-w-xs leading-relaxed">
        By continuing, you agree to our{' '}
        <Link href="/terms" className="underline hover:text-slate-600">Terms</Link>{' '}
        and{' '}
        <Link href="/privacy" className="underline hover:text-slate-600">Privacy Policy</Link>.
      </p>
    </div>
  )
}
