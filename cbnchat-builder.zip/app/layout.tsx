import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Toaster } from '@/components/ui/sonner'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'CBNchat — Instagram Automation for Christian Media',
  description:
    'Automate Instagram comments and DMs, capture CRM leads, and build multi-step flows — purpose-built for Christian media organizations.',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable}`} style={{ background: '#f8fafc', color: '#0f172a' }}>
      <body className="font-sans antialiased" style={{ background: '#f8fafc', color: '#0f172a' }}>
        {children}
        <Toaster position="bottom-right" richColors />
      </body>
    </html>
  )
}
