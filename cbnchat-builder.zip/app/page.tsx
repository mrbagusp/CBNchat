'use client'

import Link from 'next/link'
import {
  MessageCircle,
  Zap,
  Users,
  BarChart3,
  ArrowRight,
  CheckCircle2,
  Instagram,
  Globe,
  Shield,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

const FEATURES = [
  {
    icon: MessageCircle,
    title: 'Comment & DM Automation',
    desc: 'Auto-reply to comments, send DMs, and guide followers through custom flows.',
  },
  {
    icon: Zap,
    title: 'AI-Powered Responses',
    desc: 'GPT-4o contextual replies trained on your ministry knowledge base.',
  },
  {
    icon: Users,
    title: 'CRM Lead Capture',
    desc: 'Push captured contacts to your existing CRM via signed outbound webhooks.',
  },
  {
    icon: BarChart3,
    title: 'Multi-Account Dashboard',
    desc: 'Manage all your Instagram properties from one unified workspace.',
  },
]

const ACCOUNTS = [
  'Superyouth Generation',
  'Cahaya Bagi Negeri',
  'Superbook Indonesia',
  'Ingin Didoakan',
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Nav */}
      <header className="border-b border-slate-200 sticky top-0 z-50 bg-white/95 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-teal-700 flex items-center justify-center">
              <MessageCircle className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-slate-900 tracking-tight text-lg">CBNchat</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-600">
            <a href="#features" className="hover:text-slate-900 transition-colors">Features</a>
            <a href="#accounts" className="hover:text-slate-900 transition-colors">Accounts</a>
            <Link href="/privacy" className="hover:text-slate-900 transition-colors">Privacy</Link>
          </nav>
          <div className="flex items-center gap-3">
            <Link href="/login">
              <Button variant="ghost" size="sm" className="text-slate-600">Sign in</Button>
            </Link>
            <Link href="/login">
              <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-24 text-center">
        <Badge className="mb-6 bg-teal-50 text-teal-700 border-teal-200 hover:bg-teal-50">
          Purpose-built for Christian media
        </Badge>
        <h1 className="text-5xl md:text-6xl font-bold text-slate-900 tracking-tight leading-tight mb-6">
          Turn Instagram comments
          <br />
          into <span className="text-teal-700">ministry leads</span>
        </h1>
        <p className="text-xl text-slate-600 leading-relaxed max-w-2xl mx-auto mb-10">
          CBNchat automates your Instagram comment replies and DMs, captures contacts into
          your CRM, and lets you build powerful flows — without the Manychat price tag.
        </p>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <Link href="/login">
            <button className="btn-instagram flex items-center gap-2 px-8 py-3.5 rounded-lg font-semibold text-sm shadow-md">
              <Instagram className="w-4 h-4" />
              Continue with Instagram
            </button>
          </Link>
          <Link href="/login">
            <Button variant="outline" size="lg" className="rounded-lg border-slate-300 text-slate-700">
              View Demo
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
        <p className="mt-4 text-xs text-slate-400 flex items-center justify-center gap-1.5">
          <Shield className="w-3.5 h-3.5" />
          Secured via official Instagram Login API — Meta Tech Partner
        </p>
      </section>

      {/* Features */}
      <section id="features" className="bg-slate-50 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight text-center mb-12">
            Everything you need, nothing you don&apos;t
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center mb-4">
                  <f.icon className="w-5 h-5 text-teal-700" />
                </div>
                <h3 className="font-semibold text-slate-900 mb-2">{f.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Accounts */}
      <section id="accounts" className="py-20">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight mb-4">
            Powering CBN Indonesia properties
          </h2>
          <p className="text-slate-600 mb-10">
            One dashboard. Multiple Instagram accounts. Zero context switching.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            {ACCOUNTS.map((name) => (
              <div
                key={name}
                className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-full px-5 py-2.5 text-sm text-slate-700 font-medium"
              >
                <div className="w-2 h-2 rounded-full bg-teal-500" />
                {name}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-teal-700 py-20">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white tracking-tight mb-4">
            Ready to automate your ministry reach?
          </h2>
          <p className="text-teal-100 mb-8 leading-relaxed">
            Connect your Instagram account in under 60 seconds. No credit card required.
          </p>
          <Link href="/login">
            <button className="btn-instagram flex items-center gap-2 px-8 py-3.5 rounded-lg font-semibold text-sm shadow-lg mx-auto">
              <Instagram className="w-4 h-4" />
              Connect Instagram — It&apos;s Free
            </button>
          </Link>
          <div className="mt-8 flex items-center justify-center gap-8 text-sm text-teal-200">
            {['No credit card', 'Cancel anytime', 'Meta Tech Partner'].map((t) => (
              <span key={t} className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 py-10">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-teal-700 flex items-center justify-center">
              <MessageCircle className="w-3 h-3 text-white" />
            </div>
            <span className="font-medium text-slate-700">CBNchat</span>
            <span className="text-slate-300">|</span>
            <span>CBN Indonesia &copy; 2026</span>
          </div>
          <div className="flex items-center gap-6">
            <Link href="/privacy" className="hover:text-slate-700 transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-slate-700 transition-colors">Terms of Service</Link>
            <a href="mailto:support@cbnchat.local" className="hover:text-slate-700 transition-colors">Support</a>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <Globe className="w-3.5 h-3.5" />
            Meta Tech Provider
          </div>
        </div>
      </footer>
    </div>
  )
}
