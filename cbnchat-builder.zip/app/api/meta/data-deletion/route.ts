/**
 * POST /api/meta/data-deletion
 * Meta Platform Data Deletion Callback — required for Meta App Review.
 *
 * TODO(Phase 4): Verify signed_request HMAC-SHA256 signature using
 *   META_APP_SECRET env var, then queue an actual data deletion job
 *   for the user's records. See:
 *   https://developers.facebook.com/docs/development/create-an-app/app-dashboard/data-deletion-callback
 */

import { NextRequest, NextResponse } from 'next/server'

function generateCode(): string {
  // Simple random hex code — replace with a UUID or database record ID in Phase 4
  return Math.random().toString(16).slice(2, 10).toUpperCase()
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.formData().catch(() => null)
    const signedRequest = body?.get('signed_request') ?? null

    // TODO(Phase 4): Parse and verify the signed_request using HMAC-SHA256
    // const [encodedSig, payload] = signedRequest.split('.')
    // const decodedSig = Buffer.from(encodedSig, 'base64').toString('hex')
    // const expectedSig = crypto.createHmac('sha256', process.env.META_APP_SECRET!).update(payload).digest('hex')
    // if (decodedSig !== expectedSig) return NextResponse.json({ error: 'Invalid signature' }, { status: 403 })

    void signedRequest // acknowledged but not verified yet

    const confirmationCode = generateCode()
    const host = request.headers.get('host') ?? 'cbnchat.com'
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http'

    return NextResponse.json({
      url: `${protocol}://${host}/deletion-status/${confirmationCode}`,
      confirmation_code: confirmationCode,
    })
  } catch (err) {
    console.error('[data-deletion] handler error', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Meta also sends a GET to verify the endpoint is reachable
export async function GET() {
  return NextResponse.json({ status: 'ok', endpoint: '/api/meta/data-deletion' })
}
