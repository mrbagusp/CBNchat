'use client'

import { use } from 'react'
import Link from 'next/link'
import { ArrowLeft, Zap, Settings2, Eye, Play, Pause } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { AUTOMATIONS } from '@/lib/mock-data'

export default function AutomationDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const automation = AUTOMATIONS.find((a) => a.id === id)

  if (!automation) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <p className="text-slate-500">Automation not found.</p>
          <Link href="/app/automation" className="text-teal-700 text-sm font-medium hover:underline mt-2 block">
            Back to Automations
          </Link>
        </div>
      </div>
    )
  }

  const isLive = automation.status === 'live'

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Link href="/app/automation" className="text-slate-400 hover:text-slate-600 transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight truncate">{automation.name}</h1>
            <Badge className={isLive ? 'bg-teal-50 text-teal-700 border-0' : 'bg-slate-100 text-slate-600 border-0'}>
              {automation.status.charAt(0).toUpperCase() + automation.status.slice(1)}
            </Badge>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="rounded-lg border-slate-200 gap-1.5">
            <Eye className="w-3.5 h-3.5" />
            Preview
          </Button>
          <Button variant="outline" size="sm" className="rounded-lg border-slate-200 gap-1.5">
            <Settings2 className="w-3.5 h-3.5" />
            Settings
          </Button>
          {isLive ? (
            <Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-white rounded-lg gap-1.5">
              <Pause className="w-3.5 h-3.5" />
              Pause
            </Button>
          ) : (
            <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg gap-1.5">
              <Play className="w-3.5 h-3.5" />
              Set Live
            </Button>
          )}
        </div>
      </div>

      {/* Phase 2 preview notice */}
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
        <div className="w-16 h-16 bg-teal-50 rounded-2xl flex items-center justify-center mx-auto mb-5">
          <Zap className="w-8 h-8 text-teal-600" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight mb-2">Flow Builder</h2>
        <p className="text-slate-500 text-sm max-w-md mx-auto mb-1">
          The visual drag-and-drop flow builder using React Flow is built in{' '}
          <strong>Phase 2</strong> of development.
        </p>
        <p className="text-xs text-slate-400 max-w-md mx-auto mb-6">
          This page will show the full automation canvas with trigger nodes, action nodes, condition branches, AI steps, and the Post/Reel picker.
        </p>
        <div className="flex items-center justify-center gap-3">
          <div className="text-center px-6 py-3 bg-slate-50 rounded-xl border border-slate-200">
            <p className="text-2xl font-bold text-slate-900">{automation.stats.triggered.toLocaleString()}</p>
            <p className="text-xs text-slate-500 mt-0.5">Triggered</p>
          </div>
          <div className="text-center px-6 py-3 bg-teal-50 rounded-xl border border-teal-200">
            <p className="text-2xl font-bold text-teal-700">{automation.stats.completed.toLocaleString()}</p>
            <p className="text-xs text-teal-600 mt-0.5">Completed</p>
          </div>
          <div className="text-center px-6 py-3 bg-red-50 rounded-xl border border-red-200">
            <p className="text-2xl font-bold text-red-600">{automation.stats.failed}</p>
            <p className="text-xs text-red-500 mt-0.5">Failed</p>
          </div>
        </div>
      </div>
    </div>
  )
}
