'use client'

import Link from 'next/link'
import { useState } from 'react'
import {
  Zap,
  Plus,
  Folder,
  MoreHorizontal,
  Play,
  Pause,
  Edit3,
  Trash2,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  Clock,
  Filter,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/lib/store'
import { AUTOMATIONS, AUTOMATION_FOLDERS, type Automation } from '@/lib/mock-data'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const STATUS_CONFIG = {
  live: { label: 'Live', color: 'bg-teal-50 text-teal-700', dot: 'bg-teal-500' },
  draft: { label: 'Draft', color: 'bg-slate-100 text-slate-600', dot: 'bg-slate-400' },
  paused: { label: 'Paused', color: 'bg-amber-50 text-amber-700', dot: 'bg-amber-400' },
}

const TRIGGER_LABELS: Record<string, string> = {
  post_comment: 'Post Comment',
  story_reply: 'Story Reply',
  dm_message: 'DM Message',
  ad_click: 'Ad Click',
  live_comment: 'Live Comment',
}

function AutomationRow({ auto }: { auto: Automation }) {
  const cfg = STATUS_CONFIG[auto.status]

  return (
    <div className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50 transition-colors group border-b border-slate-100 last:border-b-0">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className={cn('w-2 h-2 rounded-full flex-shrink-0', cfg.dot)} />
        <div className="min-w-0">
          <Link
            href={`/app/automation/${auto.id}`}
            className="text-sm font-medium text-slate-900 hover:text-teal-700 transition-colors truncate block"
          >
            {auto.name}
          </Link>
          <p className="text-xs text-slate-500 mt-0.5">{TRIGGER_LABELS[auto.trigger_type] ?? auto.trigger_type}</p>
        </div>
      </div>

      <div className="flex items-center gap-6 ml-4">
        {/* Stats */}
        <div className="hidden md:flex items-center gap-5 text-right">
          <div>
            <p className="text-sm font-semibold text-slate-900">{auto.stats.triggered.toLocaleString()}</p>
            <p className="text-xs text-slate-400">triggered</p>
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900">{auto.stats.completed.toLocaleString()}</p>
            <p className="text-xs text-slate-400">completed</p>
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900">{auto.stats.failed}</p>
            <p className="text-xs text-slate-400">failed</p>
          </div>
        </div>

        {/* Status badge */}
        <Badge className={cn('text-[11px] font-medium border-0 px-2.5 py-0.5', cfg.color)}>
          {cfg.label}
        </Badge>

        {/* Actions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-7 h-7 rounded flex items-center justify-center text-slate-400 hover:bg-slate-200 hover:text-slate-600 opacity-0 group-hover:opacity-100 transition-all">
              <MoreHorizontal className="w-4 h-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-40 rounded-xl" align="end">
            <DropdownMenuItem className="gap-2 cursor-pointer">
              <Edit3 className="w-4 h-4" /> Edit
            </DropdownMenuItem>
            {auto.status === 'live' ? (
              <DropdownMenuItem className="gap-2 cursor-pointer">
                <Pause className="w-4 h-4" /> Pause
              </DropdownMenuItem>
            ) : (
              <DropdownMenuItem className="gap-2 cursor-pointer">
                <Play className="w-4 h-4" /> Set Live
              </DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem className="gap-2 text-red-600 cursor-pointer">
              <Trash2 className="w-4 h-4" /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}

function FolderSection({
  folderId,
  name,
  automations,
}: {
  folderId: string | null
  name: string
  automations: Automation[]
}) {
  const [open, setOpen] = useState(true)
  if (automations.length === 0) return null

  return (
    <div className="mb-4">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 hover:text-slate-700 transition-colors"
      >
        {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        <Folder className="w-3.5 h-3.5" />
        {name}
        <span className="text-slate-400 font-normal normal-case tracking-normal">({automations.length})</span>
      </button>
      {open && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
          {automations.map((a) => (
            <AutomationRow key={a.id} auto={a} />
          ))}
        </div>
      )}
    </div>
  )
}

export default function AutomationsPage() {
  const activeWorkspaceId = useAppStore((s) => s.activeWorkspaceId)
  const workspaceAutomations = AUTOMATIONS.filter((a) => a.workspace_id === activeWorkspaceId)
  const folders = AUTOMATION_FOLDERS.filter((f) => f.workspace_id === activeWorkspaceId)

  // Group: per folder, then unfiled
  const byFolder: Record<string, Automation[]> = {}
  for (const folder of folders) {
    byFolder[folder.id] = workspaceAutomations.filter((a) => a.folder_id === folder.id)
  }
  const unfiled = workspaceAutomations.filter((a) => a.folder_id === null)

  const liveCount = workspaceAutomations.filter((a) => a.status === 'live').length
  const totalTriggered = workspaceAutomations.reduce((s, a) => s + a.stats.triggered, 0)

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Automations</h1>
            <Badge className="bg-teal-50 text-teal-700 border-0 text-xs">{workspaceAutomations.length} total</Badge>
          </div>
          <p className="text-sm text-slate-500">
            {liveCount} live &middot; {totalTriggered.toLocaleString()} total triggers
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="rounded-lg border-slate-200 text-slate-600 gap-1.5">
            <Filter className="w-3.5 h-3.5" />
            Filter
          </Button>
          <Link href="/app/automation/new">
            <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              New Automation
            </Button>
          </Link>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { icon: CheckCircle2, label: 'Live', value: liveCount, color: 'text-teal-600', bg: 'bg-teal-50' },
          { icon: Clock, label: 'Draft', value: workspaceAutomations.filter(a => a.status === 'draft').length, color: 'text-slate-500', bg: 'bg-slate-100' },
          { icon: AlertCircle, label: 'Paused', value: workspaceAutomations.filter(a => a.status === 'paused').length, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((s) => (
          <div key={s.label} className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center gap-3">
            <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center', s.bg)}>
              <s.icon className={cn('w-4.5 h-4.5', s.color)} />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-900">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Column headers */}
      <div className="flex items-center justify-between px-5 py-2 text-xs font-medium text-slate-400 uppercase tracking-wide mb-1">
        <span>Name</span>
        <div className="hidden md:flex items-center gap-5 mr-28">
          <span className="w-14 text-right">Triggered</span>
          <span className="w-14 text-right">Completed</span>
          <span className="w-10 text-right">Failed</span>
        </div>
      </div>

      {/* Folders */}
      {folders.map((folder) => (
        <FolderSection
          key={folder.id}
          folderId={folder.id}
          name={folder.name}
          automations={byFolder[folder.id] ?? []}
        />
      ))}

      {/* Unfiled */}
      {unfiled.length > 0 && (
        <FolderSection folderId={null} name="Unfiled" automations={unfiled} />
      )}

      {workspaceAutomations.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
          <div className="w-12 h-12 bg-teal-50 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Zap className="w-6 h-6 text-teal-600" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-2">No automations yet</h3>
          <p className="text-sm text-slate-500 mb-4">Create your first flow to start automating replies and capturing leads.</p>
          <Link href="/app/automation/new">
            <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
              + New Automation
            </Button>
          </Link>
        </div>
      )}
    </div>
  )
}
