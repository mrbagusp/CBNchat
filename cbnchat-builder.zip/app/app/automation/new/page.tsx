'use client'

import Link from 'next/link'
import { ArrowLeft, Zap, Instagram, MessageCircle, Heart, Tv2, Radio } from 'lucide-react'
import { Button } from '@/components/ui/button'

const TRIGGER_TYPES = [
  {
    id: 'post_comment',
    label: 'Post or Reel Comment',
    desc: 'Trigger when someone comments on your post or reel',
    icon: MessageCircle,
    iconBg: 'bg-pink-50',
    iconColor: 'text-pink-600',
  },
  {
    id: 'story_reply',
    label: 'Story Reply',
    desc: 'Trigger when someone replies to your story',
    icon: Heart,
    iconBg: 'bg-violet-50',
    iconColor: 'text-violet-600',
  },
  {
    id: 'dm_message',
    label: 'Direct Message',
    desc: 'Trigger when someone sends you a DM with specific keywords',
    icon: Instagram,
    iconBg: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'live_comment',
    label: 'Live Comment',
    desc: 'Trigger during a Live broadcast when someone comments',
    icon: Tv2,
    iconBg: 'bg-red-50',
    iconColor: 'text-red-500',
  },
  {
    id: 'ad_click',
    label: 'Instagram Ad Click',
    desc: 'Trigger when someone clicks through from an Instagram Ad',
    icon: Radio,
    iconBg: 'bg-amber-50',
    iconColor: 'text-amber-600',
  },
]

export default function NewAutomationPage() {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Link href="/app/automation" className="text-slate-400 hover:text-slate-600 transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">New Automation</h1>
          <p className="text-sm text-slate-500 mt-0.5">Choose a trigger to start building your flow</p>
        </div>
      </div>

      {/* Phase 2 notice */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
        <Zap className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
        <p className="text-sm text-amber-800">
          <strong>Phase 2:</strong> The full drag-and-drop flow builder (React Flow canvas, node editor, trigger modal with Post/Reel picker) is coming next. For now, select a trigger type to preview the structure.
        </p>
      </div>

      <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">Select a Trigger</h2>

      <div className="space-y-2">
        {TRIGGER_TYPES.map((t) => (
          <Link
            key={t.id}
            href={`/app/automation/new/${t.id}`}
            className="flex items-center gap-4 bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md hover:border-teal-300 transition-all group"
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${t.iconBg}`}>
              <t.icon className={`w-5 h-5 ${t.iconColor}`} />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-slate-900 text-sm group-hover:text-teal-700 transition-colors">{t.label}</p>
              <p className="text-xs text-slate-500 mt-0.5">{t.desc}</p>
            </div>
            <svg className="w-4 h-4 text-slate-300 group-hover:text-teal-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        ))}
      </div>
    </div>
  )
}
