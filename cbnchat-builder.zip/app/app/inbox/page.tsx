import { Inbox, MessageSquare, Clock } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export default function InboxPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Inbox</h1>
          <p className="text-sm text-slate-500 mt-1">Unified DMs and comment replies</p>
        </div>
        <Badge className="bg-amber-50 text-amber-700 border-amber-200 text-xs">Phase 6</Badge>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
        <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-5">
          <Inbox className="w-8 h-8 text-slate-400" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight mb-2">Unified Inbox</h2>
        <p className="text-slate-500 text-sm max-w-md mx-auto mb-6">
          The unified inbox — showing all DMs, comment replies, and story mentions in one place — is planned for Phase 6.
        </p>
        <div className="flex items-center justify-center gap-6 text-sm text-slate-400">
          <span className="flex items-center gap-1.5">
            <MessageSquare className="w-4 h-4" />
            DM inbox
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            Comment replies
          </span>
        </div>
      </div>
    </div>
  )
}
