import { Radio } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export default function BroadcastsPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Broadcasts</h1>
          <p className="text-sm text-slate-500 mt-1">Send mass DMs to your subscriber list</p>
        </div>
        <Badge className="bg-amber-50 text-amber-700 border-amber-200 text-xs">Phase 6</Badge>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
        <div className="w-16 h-16 bg-violet-50 rounded-2xl flex items-center justify-center mx-auto mb-5">
          <Radio className="w-8 h-8 text-violet-500" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight mb-2">Broadcast Messages</h2>
        <p className="text-slate-500 text-sm max-w-md mx-auto">
          Send bulk DMs to your subscribed contacts — segment by tags, filter by source, and schedule delivery. Coming in Phase 6.
        </p>
      </div>
    </div>
  )
}
