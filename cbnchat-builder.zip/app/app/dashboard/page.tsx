import { BarChart3 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export default function DashboardPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Analytics Dashboard</h1>
          <p className="text-sm text-slate-500 mt-1">Detailed charts and performance reports</p>
        </div>
        <Badge className="bg-amber-50 text-amber-700 border-amber-200 text-xs">Phase 6</Badge>
      </div>
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-5">
          <BarChart3 className="w-8 h-8 text-blue-500" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight mb-2">Full Analytics</h2>
        <p className="text-slate-500 text-sm max-w-md mx-auto">
          Recharts-powered time-series charts, per-automation breakdowns, and CRM lead funnel analysis. Coming in Phase 6.
        </p>
      </div>
    </div>
  )
}
