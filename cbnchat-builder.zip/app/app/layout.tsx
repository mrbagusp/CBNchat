import dynamic from 'next/dynamic'

// Disable SSR entirely for the /app/* shell.
// Sidebar, Topbar, and all child pages use Zustand (client state).
// Running them on the server creates a hydration mismatch → white/black flash.
// SSR is not needed here — this is a logged-in app shell, not a public page.
const AppShell = dynamic(
  () => import('@/components/cbnchat/app-shell').then((m) => m.AppShell),
  {
    ssr: false,
    loading: () => (
      <div style={{ background: '#f8fafc', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', border: '3px solid #0F766E', borderTopColor: 'transparent', animation: 'spin 0.7s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
      </div>
    ),
  }
)

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return <AppShell>{children}</AppShell>
}
