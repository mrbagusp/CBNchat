'use client'

import { Instagram, Plus, Wifi, WifiOff, Crown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { WORKSPACES } from '@/lib/mock-data'

function formatFollowers(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(0)}K`
  return n.toString()
}

export default function WorkspacesSettingsPage() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Workspaces</h1>
          <p className="text-sm text-slate-500 mt-1">Manage connected Instagram accounts</p>
        </div>
        <a href="/api/auth/instagram/start">
          <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            Connect Account
          </Button>
        </a>
      </div>

      <div className="space-y-3">
        {WORKSPACES.map((ws) => (
          <div
            key={ws.id}
            className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                <Instagram className="w-5 h-5 text-slate-500" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-slate-900">{ws.name}</p>
                  {ws.plan === 'pro' && <Crown className="w-3.5 h-3.5 text-amber-500" />}
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  {ws.status === 'connected' ? (
                    <Wifi className="w-3 h-3 text-teal-500" />
                  ) : (
                    <WifiOff className="w-3 h-3 text-slate-400" />
                  )}
                  <p className="text-xs text-slate-500">
                    @{ws.ig_username}
                    {ws.follower_count > 0 && ` · ${formatFollowers(ws.follower_count)} followers`}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge
                className={
                  ws.status === 'connected'
                    ? 'bg-teal-50 text-teal-700 border-0 text-[11px]'
                    : 'bg-slate-100 text-slate-500 border-0 text-[11px]'
                }
              >
                {ws.status === 'connected' ? 'Connected' : 'Disconnected'}
              </Badge>
              {ws.status !== 'connected' && (
                <a href="/api/auth/instagram/start">
                  <Button size="sm" variant="outline" className="rounded-lg border-slate-200 text-xs h-7 px-3">
                    Reconnect
                  </Button>
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
