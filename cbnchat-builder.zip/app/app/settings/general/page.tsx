'use client'

import { useState } from 'react'
import { Building2, Globe, Shield, Save } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { ORGANIZATION } from '@/lib/mock-data'

export default function GeneralSettingsPage() {
  const [orgName, setOrgName] = useState(ORGANIZATION.name)
  const [slug, setSlug] = useState(ORGANIZATION.slug)
  const [saved, setSaved] = useState(false)

  function handleSave() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">General Settings</h1>
        <p className="text-sm text-slate-500 mt-1">Manage your organization details and preferences</p>
      </div>

      {/* Organization */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm mb-5">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-teal-50 flex items-center justify-center">
            <Building2 className="w-4 h-4 text-teal-700" />
          </div>
          <h2 className="font-semibold text-slate-900">Organization</h2>
        </div>
        <div className="space-y-4">
          <div>
            <Label className="text-xs text-slate-600 font-medium">Organization Name</Label>
            <Input
              value={orgName}
              onChange={(e) => setOrgName(e.target.value)}
              className="mt-1 h-9 text-sm rounded-lg border-slate-200"
            />
          </div>
          <div>
            <Label className="text-xs text-slate-600 font-medium">Slug</Label>
            <div className="flex items-center mt-1">
              <span className="h-9 px-3 flex items-center bg-slate-50 border border-r-0 border-slate-200 rounded-l-lg text-sm text-slate-500">
                cbnchat.io/
              </span>
              <Input
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                className="h-9 text-sm rounded-l-none border-slate-200"
              />
            </div>
          </div>
          <div>
            <Label className="text-xs text-slate-600 font-medium">Plan</Label>
            <div className="mt-1 flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-900 capitalize">{ORGANIZATION.plan}</span>
              <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">Trial</span>
            </div>
          </div>
        </div>
      </div>

      <Separator className="my-5" />

      <Button
        onClick={handleSave}
        className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg gap-1.5"
      >
        <Save className="w-4 h-4" />
        {saved ? 'Saved!' : 'Save Changes'}
      </Button>
    </div>
  )
}
