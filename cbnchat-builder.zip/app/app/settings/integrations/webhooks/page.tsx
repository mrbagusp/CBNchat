'use client'

import { useState } from 'react'
import { Webhook, Plus, Trash2, Copy, RefreshCw, CheckCircle2, XCircle, Eye, EyeOff, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

interface WebhookConfig {
  id: string
  name: string
  url: string
  secret: string
  events: string[]
  enabled: boolean
  lastDelivery: string | null
  lastStatus: 'success' | 'failed' | null
}

const SEED_WEBHOOKS: WebhookConfig[] = [
  {
    id: 'wh-001',
    name: 'CRM — HubSpot Contact Push',
    url: 'https://crm.example.com/api/cbnchat/contacts',
    secret: 'whsec_abc123xyz',
    events: ['contact.created', 'contact.updated'],
    enabled: true,
    lastDelivery: '2026-04-16T07:15:00Z',
    lastStatus: 'success',
  },
  {
    id: 'wh-002',
    name: 'Automation Run Log',
    url: 'https://n8n.example.com/webhook/auto-runs',
    secret: 'whsec_def456uvw',
    events: ['automation.triggered', 'automation.completed', 'automation.failed'],
    enabled: false,
    lastDelivery: '2026-04-14T12:00:00Z',
    lastStatus: 'failed',
  },
]

const ALL_EVENTS = [
  'contact.created',
  'contact.updated',
  'automation.triggered',
  'automation.completed',
  'automation.failed',
  'broadcast.sent',
]

function WebhookRow({
  wh,
  onDelete,
}: {
  wh: WebhookConfig
  onDelete: (id: string) => void
}) {
  const [showSecret, setShowSecret] = useState(false)
  const [copied, setCopied] = useState(false)

  function copySecret() {
    navigator.clipboard.writeText(wh.secret)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={cn('w-2.5 h-2.5 rounded-full flex-shrink-0', wh.enabled ? 'bg-teal-500' : 'bg-slate-300')} />
          <div>
            <p className="font-semibold text-slate-900 text-sm">{wh.name}</p>
            <p className="text-xs text-slate-400 mt-0.5 font-mono break-all">{wh.url}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {wh.lastStatus === 'success' && (
            <span className="flex items-center gap-1 text-xs text-teal-600">
              <CheckCircle2 className="w-3.5 h-3.5" /> OK
            </span>
          )}
          {wh.lastStatus === 'failed' && (
            <span className="flex items-center gap-1 text-xs text-red-500">
              <XCircle className="w-3.5 h-3.5" /> Failed
            </span>
          )}
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 text-slate-400 hover:text-red-500"
            onClick={() => onDelete(wh.id)}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Secret */}
      <div className="flex items-center gap-2">
        <Shield className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
        <code className="text-xs text-slate-600 font-mono flex-1 bg-slate-50 px-2 py-1 rounded-md">
          {showSecret ? wh.secret : '••••••••••••••••'}
        </code>
        <button
          onClick={() => setShowSecret((v) => !v)}
          className="text-slate-400 hover:text-slate-600"
        >
          {showSecret ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
        </button>
        <button onClick={copySecret} className="text-slate-400 hover:text-slate-600">
          {copied
            ? <CheckCircle2 className="w-3.5 h-3.5 text-teal-500" />
            : <Copy className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Events */}
      <div className="flex flex-wrap gap-1.5">
        {wh.events.map((ev) => (
          <Badge key={ev} className="text-[10px] bg-slate-100 text-slate-600 border-0 font-mono hover:bg-slate-100">
            {ev}
          </Badge>
        ))}
      </div>

      {/* Last delivery */}
      {wh.lastDelivery && (
        <p className="text-[11px] text-slate-400">
          Last delivery: {new Date(wh.lastDelivery).toLocaleString()}
        </p>
      )}
    </div>
  )
}

export default function WebhooksPage() {
  const [webhooks, setWebhooks] = useState(SEED_WEBHOOKS)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newUrl, setNewUrl] = useState('')
  const [newName, setNewName] = useState('')

  function handleDelete(id: string) {
    setWebhooks((prev) => prev.filter((w) => w.id !== id))
  }

  function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    const newWh: WebhookConfig = {
      id: `wh-${Date.now()}`,
      name: newName || 'New Webhook',
      url: newUrl,
      secret: `whsec_${Math.random().toString(36).slice(2, 14)}`,
      events: ['contact.created'],
      enabled: true,
      lastDelivery: null,
      lastStatus: null,
    }
    setWebhooks((prev) => [...prev, newWh])
    setNewName('')
    setNewUrl('')
    setShowAddForm(false)
  }

  return (
    <div className="p-6 max-w-3xl">
      <div className="flex items-start justify-between mb-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">CRM Webhooks</h1>
          <p className="text-sm text-slate-500 mt-1">
            Push contact and automation events to your CRM via signed outbound webhooks.
          </p>
        </div>
        <Button
          size="sm"
          className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg gap-1.5"
          onClick={() => setShowAddForm(true)}
        >
          <Plus className="w-3.5 h-3.5" />
          Add Webhook
        </Button>
      </div>

      {/* HMAC signing note */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-start gap-2.5 mb-6 mt-4">
        <Shield className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-amber-700">
          <span className="font-semibold">HMAC-SHA256 signing enabled.</span> Every payload includes an{' '}
          <code className="bg-amber-100 px-1 rounded">X-CBNchat-Signature</code> header.
          Verify it on your server to ensure authenticity.
        </div>
      </div>

      {/* Add form */}
      {showAddForm && (
        <form
          onSubmit={handleAdd}
          className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm mb-5 space-y-3"
        >
          <h3 className="font-semibold text-slate-900 text-sm">New Webhook Endpoint</h3>
          <div>
            <label className="text-xs text-slate-500 font-medium block mb-1">Name</label>
            <Input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. HubSpot Contact Push"
              className="h-9 text-sm rounded-lg border-slate-200"
            />
          </div>
          <div>
            <label className="text-xs text-slate-500 font-medium block mb-1">Endpoint URL</label>
            <Input
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              placeholder="https://your-crm.example.com/webhook"
              type="url"
              required
              className="h-9 text-sm rounded-lg border-slate-200 font-mono"
            />
          </div>
          <div className="flex gap-2 pt-1">
            <Button type="submit" size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
              Create
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="rounded-lg border-slate-200"
              onClick={() => setShowAddForm(false)}
            >
              Cancel
            </Button>
          </div>
        </form>
      )}

      {/* Webhook list */}
      <div className="space-y-4">
        {webhooks.map((wh) => (
          <WebhookRow key={wh.id} wh={wh} onDelete={handleDelete} />
        ))}
        {webhooks.length === 0 && (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
            <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Webhook className="w-6 h-6 text-slate-400" />
            </div>
            <p className="text-sm font-medium text-slate-600">No webhooks configured</p>
            <p className="text-xs text-slate-400 mt-1">Add one to start pushing data to your CRM.</p>
          </div>
        )}
      </div>

      {/* Events reference */}
      <div className="mt-8 bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <h2 className="text-sm font-semibold text-slate-700 mb-3">Available Event Types</h2>
        <div className="grid grid-cols-2 gap-2">
          {ALL_EVENTS.map((ev) => (
            <div key={ev} className="flex items-center gap-2">
              <RefreshCw className="w-3 h-3 text-teal-500 flex-shrink-0" />
              <code className="text-xs font-mono text-slate-600">{ev}</code>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
