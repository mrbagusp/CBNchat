'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Settings, Users, Wifi, Webhook, CreditCard } from 'lucide-react'

const SETTINGS_NAV = [
  { href: '/app/settings/general', label: 'General', icon: Settings },
  { href: '/app/settings/team', label: 'Team', icon: Users },
  { href: '/app/settings/workspaces', label: 'Workspaces', icon: Wifi },
  { href: '/app/settings/integrations/webhooks', label: 'Webhooks', icon: Webhook },
  { href: '/app/settings/billing', label: 'Billing', icon: CreditCard },
]

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  return (
    <div className="flex h-full">
      {/* Settings sidebar */}
      <div className="w-52 border-r border-slate-200 bg-white flex-shrink-0 p-4">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3 px-2">Settings</p>
        <nav className="space-y-0.5">
          {SETTINGS_NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                pathname === item.href
                  ? 'bg-teal-50 text-teal-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              )}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {children}
      </div>
    </div>
  )
}
