import { Users, UserPlus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { DEMO_PROFILE } from '@/lib/mock-data'

export default function TeamSettingsPage() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Team</h1>
          <p className="text-sm text-slate-500 mt-1">Manage members and their roles</p>
        </div>
        <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg gap-1.5">
          <UserPlus className="w-3.5 h-3.5" />
          Invite Member
        </Button>
      </div>
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <div className="flex items-center justify-between px-5 py-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-teal-100 flex items-center justify-center">
              <Users className="w-4 h-4 text-teal-700" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-900">{DEMO_PROFILE.full_name}</p>
              <p className="text-xs text-slate-500">{DEMO_PROFILE.email}</p>
            </div>
          </div>
          <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-full capitalize">
            {DEMO_PROFILE.role}
          </span>
        </div>
      </div>
    </div>
  )
}
