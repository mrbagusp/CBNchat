'use client'

import { CreditCard, Zap, CheckCircle2, ArrowRight, AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAppStore } from '@/lib/store'
import { WORKSPACES } from '@/lib/mock-data'

const PLANS = [
  {
    name: 'Free',
    price: 'Rp 0',
    period: '/mo',
    description: 'For getting started.',
    features: ['1 Instagram account', '500 automation runs/mo', 'Basic comment automation', 'Email support'],
    cta: 'Current plan',
    highlight: false,
  },
  {
    name: 'Pro',
    price: 'Rp 299k',
    period: '/mo',
    description: 'For growing ministries.',
    features: [
      'Up to 5 Instagram accounts',
      'Unlimited automation runs',
      'AI-powered replies',
      'CRM webhook pushes',
      'Priority support',
      'Analytics dashboard',
    ],
    cta: 'Upgrade to Pro',
    highlight: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For large organisations.',
    features: [
      'Unlimited accounts',
      'Custom AI training',
      'Dedicated support',
      'SLA guarantee',
      'On-premise option',
    ],
    cta: 'Contact us',
    highlight: false,
  },
]

export default function BillingPage() {
  const activeWorkspaceId = useAppStore((s) => s.activeWorkspaceId)
  const workspace = WORKSPACES.find((w) => w.id === activeWorkspaceId) ?? WORKSPACES[0]

  const trialEnd = workspace.trial_ends_at ? new Date(workspace.trial_ends_at) : null
  const daysLeft = trialEnd
    ? Math.max(0, Math.ceil((trialEnd.getTime() - Date.now()) / 86_400_000))
    : null

  return (
    <div className="p-6 max-w-4xl">
      <h1 className="text-2xl font-bold text-slate-900 tracking-tight mb-1">Billing &amp; Plan</h1>
      <p className="text-sm text-slate-500 mb-8">Manage your subscription and usage.</p>

      {/* Current plan status */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm mb-8 flex items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center">
            <CreditCard className="w-5 h-5 text-teal-700" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <p className="font-semibold text-slate-900">{workspace.name}</p>
              <Badge className="text-[10px] bg-amber-100 text-amber-700 border-0 hover:bg-amber-100 capitalize">
                {workspace.plan} plan
              </Badge>
            </div>
            <p className="text-sm text-slate-500">
              {workspace.status === 'connected' ? 'Account connected' : 'Account disconnected'}
            </p>
          </div>
        </div>
        {daysLeft !== null && (
          <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
            <p className="text-sm text-amber-700 font-medium">
              Trial ends in {daysLeft} day{daysLeft !== 1 ? 's' : ''}
            </p>
          </div>
        )}
      </div>

      {/* Usage this month */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm mb-8">
        <h2 className="text-sm font-semibold text-slate-700 mb-4">Usage this month</h2>
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Automation Runs', used: 347, limit: 500, unit: '' },
            { label: 'Active Automations', used: 5, limit: 10, unit: '' },
            { label: 'CRM Pushes', used: 89, limit: 500, unit: '' },
          ].map((item) => {
            const pct = Math.round((item.used / item.limit) * 100)
            return (
              <div key={item.label}>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-xs text-slate-500">{item.label}</p>
                  <p className="text-xs font-semibold text-slate-700">
                    {item.used} / {item.limit}
                  </p>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-teal-500 transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Plan cards */}
      <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
        Available Plans
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PLANS.map((plan) => (
          <div
            key={plan.name}
            className={`rounded-xl border p-5 shadow-sm flex flex-col ${
              plan.highlight
                ? 'border-teal-500 bg-teal-700 text-white shadow-lg'
                : 'border-slate-200 bg-white'
            }`}
          >
            <div className="mb-4">
              <p className={`text-xs font-semibold uppercase tracking-wide mb-1 ${plan.highlight ? 'text-teal-200' : 'text-slate-400'}`}>
                {plan.name}
              </p>
              <div className="flex items-end gap-1">
                <span className={`text-2xl font-bold ${plan.highlight ? 'text-white' : 'text-slate-900'}`}>
                  {plan.price}
                </span>
                {plan.period && (
                  <span className={`text-sm mb-0.5 ${plan.highlight ? 'text-teal-200' : 'text-slate-400'}`}>
                    {plan.period}
                  </span>
                )}
              </div>
              <p className={`text-xs mt-1 ${plan.highlight ? 'text-teal-100' : 'text-slate-500'}`}>
                {plan.description}
              </p>
            </div>
            <ul className="space-y-2 flex-1 mb-5">
              {plan.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-xs">
                  <CheckCircle2 className={`w-3.5 h-3.5 flex-shrink-0 ${plan.highlight ? 'text-teal-200' : 'text-teal-600'}`} />
                  <span className={plan.highlight ? 'text-teal-50' : 'text-slate-600'}>{f}</span>
                </li>
              ))}
            </ul>
            <Button
              size="sm"
              className={
                plan.highlight
                  ? 'bg-white text-teal-700 hover:bg-teal-50 rounded-lg w-full font-semibold'
                  : workspace.plan === plan.name.toLowerCase()
                  ? 'bg-slate-100 text-slate-500 hover:bg-slate-100 rounded-lg w-full cursor-default'
                  : 'bg-teal-700 hover:bg-teal-800 text-white rounded-lg w-full'
              }
            >
              {workspace.plan === plan.name.toLowerCase() ? (
                <span className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" /> Current Plan
                </span>
              ) : (
                <span className="flex items-center gap-1.5">
                  {plan.cta}
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              )}
            </Button>
          </div>
        ))}
      </div>

      {/* Invoices stub */}
      <div className="mt-8 bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <h2 className="text-sm font-semibold text-slate-700 mb-4">Invoices</h2>
        <div className="py-8 text-center text-slate-400 text-sm">
          No invoices yet — billing begins when you upgrade.
        </div>
      </div>
    </div>
  )
}
