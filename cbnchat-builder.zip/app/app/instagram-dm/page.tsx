'use client'

import Link from 'next/link'
import { Instagram, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'
import { AUTOMATIONS } from '@/lib/mock-data'
import { Badge } from '@/components/ui/badge'

export default function InstagramDMPage() {
  const activeWorkspaceId = useAppStore((s) => s.activeWorkspaceId)
  const igAutomations = AUTOMATIONS.filter(
    (a) => a.workspace_id === activeWorkspaceId
  )

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Instagram DM</h1>
          <p className="text-sm text-slate-500 mt-1">All Instagram-triggered automations for this workspace</p>
        </div>
        <Link href="/app/automation/new">
          <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
            + New Automation
          </Button>
        </Link>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        {igAutomations.map((auto) => (
          <Link
            key={auto.id}
            href={`/app/automation/${auto.id}`}
            className="flex items-center justify-between px-5 py-4 hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-b-0 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-pink-50 flex items-center justify-center">
                <Instagram className="w-4 h-4 text-pink-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-900 group-hover:text-teal-700 transition-colors">{auto.name}</p>
                <p className="text-xs text-slate-500 capitalize mt-0.5">{auto.trigger_type.replace('_', ' ')}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge
                className={
                  auto.status === 'live'
                    ? 'bg-teal-50 text-teal-700 border-0 text-[11px]'
                    : auto.status === 'paused'
                    ? 'bg-amber-50 text-amber-700 border-0 text-[11px]'
                    : 'bg-slate-100 text-slate-600 border-0 text-[11px]'
                }
              >
                {auto.status}
              </Badge>
              <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-teal-500 transition-colors" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
