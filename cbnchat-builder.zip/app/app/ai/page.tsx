'use client'

import { useState } from 'react'
import { Sparkles, Brain, Zap, Settings2, MessageSquare, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'

const DEFAULT_SYSTEM_PROMPT = `You are a friendly assistant for Superyouth Generation, a Christian youth media community in Indonesia. Respond to Instagram comments in Bahasa Indonesia, warmly and concisely (max 2 sentences). Always invite the commenter to DM us for prayer requests or to join our WhatsApp community. Never discuss political or divisive topics.`

const DEFAULT_KNOWLEDGE_BASE = `About Superyouth Generation:
- Christian youth media community in Indonesia
- Founded in 2010, focused on young people 18-35
- Programs: prayer meetings, Bible studies, youth camps
- WhatsApp community: available upon request via DM
- Yesus Curhat: weekly online prayer session every Thursday 8PM WIB
- Website: superyouthgen.id

Common FAQs:
- "Bagaimana cara bergabung?" → Kirim DM untuk info lebih lanjut
- "Ada acara apa?" → Cek Instagram stories atau kirim DM untuk jadwal terbaru
- "Link WhatsApp?" → Kirim DM dengan kata kunci "WA" untuk mendapat link`

export default function AIPage() {
  const [enabled, setEnabled] = useState(true)
  const [model, setModel] = useState('gpt-4o-mini')
  const [temperature, setTemperature] = useState('0.7')
  const [maxTokens, setMaxTokens] = useState('300')
  const [systemPrompt, setSystemPrompt] = useState(DEFAULT_SYSTEM_PROMPT)
  const [knowledgeBase, setKnowledgeBase] = useState(DEFAULT_KNOWLEDGE_BASE)
  const [fallback, setFallback] = useState('Terima kasih sudah komentar! Silahkan DM kami untuk info lebih lanjut. 🙏')
  const [testInput, setTestInput] = useState('')
  const [testOutput, setTestOutput] = useState<string | null>(null)
  const [testing, setTesting] = useState(false)

  async function handleTest() {
    if (!testInput.trim()) return
    setTesting(true)
    setTestOutput(null)
    // Phase 3 will wire this to /api/ai/chat with real OpenAI call
    await new Promise((r) => setTimeout(r, 1200))
    setTestOutput(
      'Hai! Terima kasih sudah komentar ya! 😊 Yuk DM kita untuk info lengkap tentang komunitas Superyouth dan gabung grup WhatsApp kita! 🙏'
    )
    setTesting(false)
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">AI Assistant</h1>
            <Badge className="bg-teal-50 text-teal-700 border-0 text-xs">GPT-4o mini</Badge>
          </div>
          <p className="text-sm text-slate-500">
            Configure the AI that handles contextual DM and comment replies
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-600">{enabled ? 'Enabled' : 'Disabled'}</span>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
          <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
            Save Changes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: config */}
        <div className="lg:col-span-2 space-y-5">
          {/* Model config */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-teal-50 flex items-center justify-center">
                <Brain className="w-4 h-4 text-teal-700" />
              </div>
              <h2 className="font-semibold text-slate-900">Model Configuration</h2>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-xs text-slate-600 font-medium">Model</Label>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  className="mt-1 w-full h-9 px-3 text-sm border border-slate-200 rounded-lg bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
                >
                  <option value="gpt-4o-mini">gpt-4o-mini</option>
                  <option value="gpt-4o">gpt-4o</option>
                </select>
              </div>
              <div>
                <Label className="text-xs text-slate-600 font-medium">Temperature</Label>
                <Input
                  value={temperature}
                  onChange={(e) => setTemperature(e.target.value)}
                  className="mt-1 h-9 text-sm rounded-lg border-slate-200"
                  type="number"
                  min="0"
                  max="2"
                  step="0.1"
                />
              </div>
              <div>
                <Label className="text-xs text-slate-600 font-medium">Max Tokens</Label>
                <Input
                  value={maxTokens}
                  onChange={(e) => setMaxTokens(e.target.value)}
                  className="mt-1 h-9 text-sm rounded-lg border-slate-200"
                  type="number"
                />
              </div>
            </div>
          </div>

          {/* System prompt */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="font-semibold text-slate-900">System Prompt</h2>
              <Info className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <p className="text-xs text-slate-500 mb-3">Define the AI&apos;s persona, language, and behavioral rules.</p>
            <textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              rows={5}
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none leading-relaxed"
            />
          </div>

          {/* Knowledge base */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="font-semibold text-slate-900">Knowledge Base</h2>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Facts, FAQs, and context about your organization. The AI will reference this when replying.
            </p>
            <textarea
              value={knowledgeBase}
              onChange={(e) => setKnowledgeBase(e.target.value)}
              rows={8}
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none leading-relaxed font-mono"
            />
          </div>

          {/* Fallback */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <h2 className="font-semibold text-slate-900 mb-1">Fallback Message</h2>
            <p className="text-xs text-slate-500 mb-3">Sent if the AI fails or is disabled.</p>
            <textarea
              value={fallback}
              onChange={(e) => setFallback(e.target.value)}
              rows={2}
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </div>
        </div>

        {/* Right: playground */}
        <div className="space-y-5">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm sticky top-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-violet-50 flex items-center justify-center">
                <Zap className="w-4 h-4 text-violet-600" />
              </div>
              <h2 className="font-semibold text-slate-900">Test Playground</h2>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Enter a sample comment or DM to see how the AI responds.
            </p>

            <div className="space-y-3">
              <textarea
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                rows={3}
                placeholder="e.g. info dong kak, gimana cara joinnya?"
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none placeholder:text-slate-400"
              />
              <Button
                onClick={handleTest}
                disabled={!testInput.trim() || testing}
                className="w-full bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-sm"
              >
                {testing ? (
                  <span className="flex items-center gap-2">
                    <div className="w-3.5 h-3.5 rounded-full border-2 border-white border-t-transparent animate-spin" />
                    Generating...
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Test AI Reply
                  </span>
                )}
              </Button>
            </div>

            {testOutput && (
              <>
                <Separator className="my-4" />
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-teal-600" />
                    <p className="text-xs font-semibold text-slate-600">AI Response</p>
                  </div>
                  <div className="bg-teal-50 border border-teal-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 leading-relaxed">
                    {testOutput}
                  </div>
                  <p className="text-xs text-slate-400">Phase 3 will call real OpenAI API</p>
                </div>
              </>
            )}
          </div>

          {/* Status */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">API Status</h3>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">OpenAI Key</span>
              <Badge className="bg-amber-50 text-amber-700 border-0 text-[11px]">
                Not configured
              </Badge>
            </div>
            <p className="text-xs text-slate-400 mt-2">
              Add <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-600">OPENAI_API_KEY</code> to env vars in Phase 3
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
