'use client'

import Link from 'next/link'
import {
  Zap,
  Users,
  MessageCircle,
  Webhook,
  Instagram,
  Facebook,
  Calendar,
  Play,
  Sparkles,
  FileText,
  ArrowRight,
  CheckCircle2,
  Clock,
  AlertCircle,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { useAppStore } from '@/lib/store'
import { WORKSPACES, getDashboardStats, AUTOMATIONS, AUTOMATION_RUNS } from '@/lib/mock-data'
import { StatCard } from '@/components/cbnchat/stat-card'
import { TrialBanner } from '@/components/cbnchat/trial-banner'
import { ChannelBadge } from '@/components/cbnchat/channel-badge'

function formatFollowers(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`
  return n.toString()
}

function QuickActionCard({
  href,
  icon: Icon,
  iconBg,
  iconColor,
  title,
  desc,
  badge,
}: {
  href: string
  icon: React.ComponentType<{ className?: string }>
  iconBg: string
  iconColor: string
  title: string
  desc: string
  badge?: string
}) {
  return (
    <Link href={href} className="block group">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
        <div className="flex items-start justify-between mb-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${iconBg}`}>
            <Icon className={`w-5 h-5 ${iconColor}`} />
          </div>
          {badge && (
            <Badge className="text-[10px] bg-slate-100 text-slate-500 border-0 hover:bg-slate-100">
              {badge}
            </Badge>
          )}
        </div>
        <p className="font-semibold text-slate-900 text-sm">{title}</p>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{desc}</p>
        <div className="flex items-center gap-1 mt-3 text-xs text-teal-700 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
          Get started
          <ArrowRight className="w-3 h-3" />
        </div>
      </div>
    </Link>
  )
}

function FeatureHighlightCard({
  icon: Icon,
  iconBg,
  iconColor,
  tag,
  title,
  desc,
  ctaLabel,
}: {
  icon: React.ComponentType<{ className?: string }>
  iconBg: string
  iconColor: string
  tag: string
  title: string
  desc: string
  ctaLabel: string
}) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex items-start gap-4">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${iconBg}`}>
        <Icon className={`w-5 h-5 ${iconColor}`} />
      </div>
      <div className="flex-1 min-w-0">
        <Badge className="mb-2 text-[10px] bg-teal-50 text-teal-700 border-0 hover:bg-teal-50 uppercase tracking-wide">
          {tag}
        </Badge>
        <p className="font-semibold text-slate-900 text-sm">{title}</p>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{desc}</p>
        <button className="mt-3 flex items-center gap-1.5 text-xs text-teal-700 font-medium hover:underline">
          <Play className="w-3 h-3 fill-teal-700" />
          {ctaLabel}
        </button>
      </div>
    </div>
  )
}

function RunStatusBadge({ status }: { status: 'completed' | 'failed' | 'running' }) {
  if (status === 'completed') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-teal-50 text-teal-700">
        <CheckCircle2 className="w-3 h-3" />
        Completed
      </span>
    )
  }
  if (status === 'failed') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-red-50 text-red-600">
        <AlertCircle className="w-3 h-3" />
        Failed
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700">
      <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
      Running
    </span>
  )
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const m = Math.floor(diff / 60_000)
  const h = Math.floor(m / 60)
  const d = Math.floor(h / 24)
  if (d > 0) return `${d}d ago`
  if (h > 0) return `${h}h ago`
  if (m > 0) return `${m}m ago`
  return 'Just now'
}

export default function HomePageClient() {
  const activeWorkspaceId = useAppStore((s) => s.activeWorkspaceId)
  const workspace = WORKSPACES.find((w) => w.id === activeWorkspaceId) ?? WORKSPACES[0]
  const stats = getDashboardStats(activeWorkspaceId)
  const liveAutomations = AUTOMATIONS.filter(
    (a) => a.workspace_id === activeWorkspaceId && a.status === 'live'
  )
  const recentRuns = AUTOMATION_RUNS.slice(0, 10)

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {workspace.trial_ends_at && <TrialBanner />}

      {/* Greeting */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight">
              @{workspace.external_username}!
            </h1>
            <ChannelBadge type={workspace.channel} variant="pill" />
          </div>
          <p className="text-slate-600 mt-1 text-sm">
            Multi-channel comment, stories, DM automation
          </p>
        </div>
        <div className="flex items-center gap-3 text-sm text-slate-500">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-teal-500 animate-pulse" />
            <span className="font-medium text-slate-700">{liveAutomations.length} live</span>
          </div>
          <div className="h-4 w-px bg-slate-200" />
          <span>{formatFollowers(workspace.follower_count)} followers</span>
        </div>
      </div>

      {/* Feature highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FeatureHighlightCard
          icon={Sparkles}
          iconBg="bg-teal-50"
          iconColor="text-teal-700"
          tag="New"
          title="Automate enquiries with ChatGPT"
          desc="Let AI handle DMs and comment replies with context-aware responses from your knowledge base."
          ctaLabel="Watch Demo"
        />
        <FeatureHighlightCard
          icon={FileText}
          iconBg="bg-amber-50"
          iconColor="text-amber-600"
          tag="New · Beta"
          title="Send PDF Directly in DM"
          desc="Attach PDFs, e-books, and prayer guides — send them automatically when someone comments a keyword."
          ctaLabel="Learn More"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Triggered (7d)"
          value={stats.triggered.value}
          change={stats.triggered.change}
          sparkline={stats.sparklines.triggered}
          icon={Zap}
          iconBg="bg-teal-50"
          iconColor="text-teal-700"
        />
        <StatCard
          label="New Contacts (7d)"
          value={stats.newContacts.value}
          change={stats.newContacts.change}
          sparkline={stats.sparklines.newContacts}
          icon={Users}
          iconBg="bg-blue-50"
          iconColor="text-blue-600"
        />
        <StatCard
          label="Messages Sent (7d)"
          value={stats.messagesSent.value}
          change={stats.messagesSent.change}
          sparkline={stats.sparklines.messagesSent}
          icon={MessageCircle}
          iconBg="bg-violet-50"
          iconColor="text-violet-600"
        />
        <StatCard
          label="CRM Leads Pushed (7d)"
          value={stats.crmLeads.value}
          change={stats.crmLeads.change}
          sparkline={stats.sparklines.crmLeads}
          icon={Webhook}
          iconBg="bg-amber-50"
          iconColor="text-amber-600"
        />
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <QuickActionCard
            href="/app/automation"
            icon={Instagram}
            iconBg="bg-pink-50"
            iconColor="text-pink-600"
            title="Instagram Automation"
            desc="Automate comments, DMs, and story replies on your Instagram posts and reels."
          />
          <QuickActionCard
            href="/app/automation"
            icon={Facebook}
            iconBg="bg-blue-50"
            iconColor="text-blue-600"
            title="Facebook Automation"
            desc="Coming soon — automate Facebook Page comments and Messenger DMs."
            badge="Coming Soon"
          />
          <QuickActionCard
            href="/app/broadcasts"
            icon={Calendar}
            iconBg="bg-violet-50"
            iconColor="text-violet-600"
            title="Schedule Posts with AutoDM"
            desc="Schedule content and trigger DMs automatically when posts go live."
            badge="Coming Soon"
          />
        </div>
      </div>

      {/* Live automations */}
      {liveAutomations.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">
              Live Automations
            </h2>
            <Link href="/app/automation" className="text-xs text-teal-700 font-medium hover:underline flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            {liveAutomations.slice(0, 4).map((auto) => (
              <Link
                key={auto.id}
                href={`/app/automation/${auto.id}`}
                className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50 transition-colors group border-b border-slate-50 last:border-0"
              >
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-teal-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-slate-900 group-hover:text-teal-700 transition-colors">
                      {auto.name}
                    </p>
                    <p className="text-xs text-slate-500 capitalize">{auto.trigger_type.replace('_', ' ')}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 text-right">
                  <div className="hidden md:block">
                    <p className="text-sm font-semibold text-slate-900">{auto.stats.triggered.toLocaleString()}</p>
                    <p className="text-xs text-slate-400">triggered</p>
                  </div>
                  <div className="hidden md:block">
                    <p className="text-sm font-semibold text-slate-900">{auto.stats.completed.toLocaleString()}</p>
                    <p className="text-xs text-slate-400">completed</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-teal-600 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {auto.stats.triggered > 0
                      ? `${((auto.stats.completed / auto.stats.triggered) * 100).toFixed(0)}%`
                      : '—'}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Recent runs */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">
            Recent Automation Runs
          </h2>
          <Link href="/app/automation" className="text-xs text-teal-700 font-medium hover:underline flex items-center gap-1">
            View all <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-5 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">Time</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">Automation</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide hidden md:table-cell">Trigger</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentRuns.map((run) => (
                <tr key={run.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3 text-xs text-slate-500 whitespace-nowrap">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {timeAgo(run.started_at)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm font-medium text-slate-900 max-w-[200px] truncate">
                    {run.automation_name}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500 hidden md:table-cell max-w-[160px] truncate">
                    {run.triggered_by?.comment_text ?? '—'}
                  </td>
                  <td className="px-4 py-3">
                    <RunStatusBadge status={run.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Account overview + Getting Started */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Account Overview</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-2xl font-bold text-slate-900">{formatFollowers(workspace.follower_count)}</p>
              <p className="text-xs text-slate-500 mt-0.5">Followers</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900">{workspace.media_count.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-0.5">Posts</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900">{liveAutomations.length}</p>
              <p className="text-xs text-slate-500 mt-0.5">Live flows</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900">
                {liveAutomations.reduce((sum, a) => sum + a.stats.triggered, 0).toLocaleString()}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">Total triggered</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-slate-700">Getting Started</h3>
            <span className="text-xs text-slate-400">3 / 5 complete</span>
          </div>
          <div className="space-y-2">
            {[
              { label: 'Connect Instagram account', done: workspace.status === 'connected' },
              { label: 'Create your first automation', done: liveAutomations.length > 0 },
              { label: 'Configure AI assistant', done: false },
              { label: 'Set up CRM webhook', done: false },
              { label: 'Invite team members', done: false },
            ].map((step) => (
              <div key={step.label} className="flex items-center gap-2.5 text-sm">
                <div className={`w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 ${step.done ? 'bg-teal-500' : 'border-2 border-slate-200'}`}>
                  {step.done && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 12 12">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className={step.done ? 'text-slate-400 line-through' : 'text-slate-700'}>
                  {step.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
