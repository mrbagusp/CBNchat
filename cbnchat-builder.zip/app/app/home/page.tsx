import dynamic from 'next/dynamic'

const HomePageClient = dynamic(() => import('./home-client'), { ssr: false })

export default function HomePage() {
  return <HomePageClient />
}
