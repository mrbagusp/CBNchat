'use client'

import { useState, useMemo } from 'react'
import {
  Search,
  Download,
  Filter,
  Users,
  MessageCircle,
  AtSign,
  Clock,
  ChevronDown,
  Tag,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/lib/store'
import { CONTACTS, type Contact } from '@/lib/mock-data'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'

const SOURCE_LABELS: Record<string, string> = {
  comment: 'Comment',
  dm: 'DM',
  story_reply: 'Story Reply',
  manual: 'Manual',
}

const TAG_COLORS: Record<string, string> = {
  new_lead: 'bg-blue-50 text-blue-700',
  doa: 'bg-violet-50 text-violet-700',
  yesus_curhat: 'bg-pink-50 text-pink-700',
  paid_event: 'bg-amber-50 text-amber-700',
}

function ContactRow({ contact, onClick }: { contact: Contact; onClick: () => void }) {
  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime()
    const h = Math.floor(diff / 3_600_000)
    const d = Math.floor(h / 24)
    if (d > 0) return `${d}d ago`
    if (h > 0) return `${h}h ago`
    return 'Just now'
  }

  return (
    <tr
      className="hover:bg-slate-50 cursor-pointer border-b border-slate-100 last:border-b-0"
      onClick={onClick}
    >
      <td className="px-5 py-3.5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0">
            <span className="text-xs font-semibold text-slate-500">
              {contact.channel_username.slice(0, 2).toUpperCase()}
            </span>
          </div>
          <div>
            <p className="text-sm font-medium text-slate-900">{contact.full_name}</p>
            <p className="text-xs text-slate-500">@{contact.channel_username}</p>
          </div>
        </div>
      </td>
      <td className="px-4 py-3.5 hidden md:table-cell">
        <Badge
          className={cn(
            'text-[11px] border-0 px-2 py-0.5',
            contact.source === 'comment' ? 'bg-pink-50 text-pink-700' :
            contact.source === 'dm' ? 'bg-blue-50 text-blue-700' :
            contact.source === 'story_reply' ? 'bg-violet-50 text-violet-700' :
            'bg-slate-100 text-slate-600'
          )}
        >
          {SOURCE_LABELS[contact.source]}
        </Badge>
      </td>
      <td className="px-4 py-3.5 hidden lg:table-cell">
        <div className="flex flex-wrap gap-1">
          {contact.tags.slice(0, 2).map((tag) => (
            <span
              key={tag}
              className={cn('text-[11px] px-2 py-0.5 rounded-full font-medium', TAG_COLORS[tag] ?? 'bg-slate-100 text-slate-600')}
            >
              {tag}
            </span>
          ))}
          {contact.tags.length > 2 && (
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-500">
              +{contact.tags.length - 2}
            </span>
          )}
        </div>
      </td>
      <td className="px-4 py-3.5 hidden md:table-cell">
        <span className="text-xs text-slate-500">{timeAgo(contact.last_seen_at)}</span>
      </td>
      <td className="px-4 py-3.5">
        <div
          className={cn(
            'w-8 h-5 rounded-full transition-colors cursor-pointer flex items-center px-0.5',
            contact.subscribed ? 'bg-teal-500' : 'bg-slate-200'
          )}
          onClick={(e) => e.stopPropagation()}
        >
          <div
            className={cn(
              'w-4 h-4 rounded-full bg-white shadow-sm transition-transform',
              contact.subscribed ? 'translate-x-3' : 'translate-x-0'
            )}
          />
        </div>
      </td>
    </tr>
  )
}

export default function ContactsPage() {
  const activeWorkspaceId = useAppStore((s) => s.activeWorkspaceId)
  const workspaceContacts = CONTACTS.filter((c) => c.workspace_id === activeWorkspaceId)

  const [search, setSearch] = useState('')
  const [sourceFilter, setSourceFilter] = useState<string>('all')
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null)

  const filtered = useMemo(() => {
    let list = workspaceContacts
    if (search) {
      const q = search.toLowerCase()
      list = list.filter(
        (c) =>
          c.channel_username.toLowerCase().includes(q) ||
          c.full_name.toLowerCase().includes(q)
      )
    }
    if (sourceFilter !== 'all') {
      list = list.filter((c) => c.source === sourceFilter)
    }
    return list
  }, [workspaceContacts, search, sourceFilter])

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Contacts</h1>
          <p className="text-sm text-slate-500 mt-1">
            {workspaceContacts.length} total &middot;{' '}
            {workspaceContacts.filter((c) => c.subscribed).length} subscribed
          </p>
        </div>
        <Button variant="outline" size="sm" className="rounded-lg border-slate-200 text-slate-600 gap-1.5">
          <Download className="w-3.5 h-3.5" />
          Export CSV
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total', value: workspaceContacts.length, icon: Users, bg: 'bg-slate-50', color: 'text-slate-600' },
          { label: 'From Comments', value: workspaceContacts.filter(c => c.source === 'comment').length, icon: MessageCircle, bg: 'bg-pink-50', color: 'text-pink-600' },
          { label: 'From DMs', value: workspaceContacts.filter(c => c.source === 'dm').length, icon: AtSign, bg: 'bg-blue-50', color: 'text-blue-600' },
          { label: 'Subscribed', value: workspaceContacts.filter(c => c.subscribed).length, icon: Tag, bg: 'bg-teal-50', color: 'text-teal-600' },
        ].map((s) => (
          <div key={s.label} className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center gap-3">
            <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center', s.bg)}>
              <s.icon className={cn('w-4 h-4', s.color)} />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-900">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search contacts..."
            className="pl-9 h-9 text-sm rounded-lg border-slate-200"
          />
        </div>
        <div className="flex items-center gap-2">
          {['all', 'comment', 'dm', 'story_reply', 'manual'].map((src) => (
            <button
              key={src}
              onClick={() => setSourceFilter(src)}
              className={cn(
                'text-xs px-3 py-1.5 rounded-lg font-medium transition-colors',
                sourceFilter === src
                  ? 'bg-teal-700 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              )}
            >
              {src === 'all' ? 'All' : SOURCE_LABELS[src]}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="px-5 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">Contact</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide hidden md:table-cell">Source</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide hidden lg:table-cell">Tags</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide hidden md:table-cell">Last Seen</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">Sub.</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((contact) => (
              <ContactRow
                key={contact.id}
                contact={contact}
                onClick={() => setSelectedContact(contact)}
              />
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-sm">No contacts found</div>
        )}
      </div>

      {/* Contact drawer (simplified inline) */}
      {selectedContact && (
        <div className="fixed inset-0 z-50 flex">
          <div className="flex-1 bg-black/30" onClick={() => setSelectedContact(null)} />
          <div className="w-80 bg-white shadow-xl border-l border-slate-200 overflow-y-auto">
            <div className="p-5 border-b border-slate-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-900">Contact Profile</h3>
                <button
                  onClick={() => setSelectedContact(null)}
                  className="text-slate-400 hover:text-slate-600 text-lg leading-none"
                >
                  ×
                </button>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center">
                  <span className="text-sm font-bold text-slate-500">
                    {selectedContact.channel_username.slice(0, 2).toUpperCase()}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{selectedContact.full_name}</p>
                  <p className="text-sm text-slate-500">@{selectedContact.channel_username}</p>
                </div>
              </div>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Details</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Source</span>
                    <span className="font-medium text-slate-900 capitalize">{selectedContact.source.replace('_', ' ')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">First seen</span>
                    <span className="font-medium text-slate-900">{new Date(selectedContact.first_seen_at).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Subscribed</span>
                    <span className={selectedContact.subscribed ? 'text-teal-600 font-medium' : 'text-slate-400'}>
                      {selectedContact.subscribed ? 'Yes' : 'No'}
                    </span>
                  </div>
                </div>
              </div>
              {selectedContact.tags.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Tags</p>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedContact.tags.map((tag) => (
                      <span
                        key={tag}
                        className={cn('text-xs px-2.5 py-1 rounded-full font-medium', TAG_COLORS[tag] ?? 'bg-slate-100 text-slate-600')}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Actions</p>
                <div className="space-y-2">
                  <Button size="sm" className="w-full rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs">
                    Send DM
                  </Button>
                  <Button size="sm" variant="outline" className="w-full rounded-lg border-slate-200 text-xs">
                    Add Tag
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
