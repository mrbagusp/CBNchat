/**
 * lib/channels/index.ts
 * Channel registry + factory.
 *
 * To add a new channel (Phase 7: Facebook Page):
 *   1. Create lib/channels/facebook/adapter.ts implementing ChannelAdapter
 *   2. Import it here and set channelRegistry.facebook_page = new FacebookPageAdapter()
 *   3. Nothing else changes in the automation engine or UI shell.
 */

import { InstagramAdapter } from './instagram/adapter';
import type { ChannelAdapter, ChannelType } from './types';

// Stub for channels not yet implemented — satisfies the registry shape
class StubAdapter implements Partial<ChannelAdapter> {
  constructor(
    public readonly type: ChannelType,
    public readonly displayName: string,
    public readonly brandColor: string,
    public readonly available = false
  ) {}
}

export const channelRegistry: Record<ChannelType, ChannelAdapter | StubAdapter> = {
  instagram: new InstagramAdapter(),
  // Phase 7 — FacebookPageAdapter not yet created. Folder exists at lib/channels/facebook/
  facebook_page: new StubAdapter('facebook_page', 'Facebook Page', '#1877F2'),
  // Future phases
  tiktok: new StubAdapter('tiktok', 'TikTok', '#010101'),
  whatsapp: new StubAdapter('whatsapp', 'WhatsApp Business', '#25D366'),
};

/**
 * Get a fully-implemented channel adapter, throwing if not yet supported.
 * Use `channelRegistry[type]` directly if you only need metadata (displayName, brandColor).
 */
export function getChannel(type: ChannelType): ChannelAdapter {
  const adapter = channelRegistry[type];
  if (!adapter.available) {
    throw new Error(
      `Channel "${type}" is not yet implemented. See lib/channels/${type}/ for the Phase roadmap.`
    );
  }
  return adapter as ChannelAdapter;
}

export type { ChannelType, ChannelAdapter, NormalizedEvent } from './types';
