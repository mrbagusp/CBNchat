/**
 * lib/channels/types.ts
 * Channel-agnostic interfaces for the CBNchat channel abstraction layer.
 * Adding a new channel (Facebook, TikTok, WhatsApp) means implementing
 * ChannelAdapter — nothing else changes.
 */

export type ChannelType = 'instagram' | 'facebook_page' | 'tiktok' | 'whatsapp';

export interface ChannelCredentials {
  accessToken: string;
  refreshToken?: string;
  expiresAt: Date;
  scopes?: string[];
  /** Channel-specific extra fields (e.g. page_id for Facebook Pages) */
  extra?: Record<string, string>;
}

export interface ChannelProfile {
  externalId: string;
  username?: string;       // may be null for FB (PSID doesn't expose username)
  displayName: string;
  profilePictureUrl?: string;
  followerCount?: number;
  mediaCount?: number;
  accountType?: string;    // 'business' | 'creator' for IG, 'page' for FB
}

export interface MediaItem {
  id: string;
  type: 'IMAGE' | 'VIDEO' | 'CAROUSEL_ALBUM' | 'REEL';
  thumbnailUrl?: string;
  mediaUrl?: string;
  caption?: string;
  timestamp: Date;
  permalink?: string;
}

export interface MessageContent {
  text?: string;
  imageUrl?: string;
  videoUrl?: string;
  quickReplies?: Array<{ title: string; payload: string }>;
  buttons?: Array<{ type: 'url' | 'postback'; title: string; url?: string; payload?: string }>;
}

export interface SendResult {
  messageId: string;
  recipientId: string;
  timestamp: Date;
  status: 'sent' | 'failed';
  error?: string;
}

export type NormalizedEventType =
  | 'comment'
  | 'dm_message'
  | 'story_reply'
  | 'reaction'
  | 'postback'
  | 'ad_click'
  | 'live_comment';

export interface NormalizedEvent {
  channel: ChannelType;
  eventType: NormalizedEventType;
  externalUserId: string;      // IG user_id OR FB page-scoped user ID (PSID)
  username?: string;
  postId?: string;
  commentId?: string;
  messageId?: string;
  content: string;
  mediaUrls?: string[];
  timestamp: Date;
  raw: unknown;               // original payload for audit
}

export interface ChannelAdapter {
  readonly type: ChannelType;
  readonly displayName: string;
  readonly brandColor: string;    // hex, used in UI badges
  readonly available: boolean;    // false = not yet implemented

  // OAuth
  buildAuthUrl(state: string, redirectUri: string): string;
  exchangeCode(code: string, redirectUri: string): Promise<ChannelCredentials>;
  refreshToken(credentials: ChannelCredentials): Promise<ChannelCredentials>;
  revokeAccess(credentials: ChannelCredentials): Promise<void>;

  // Profile
  fetchProfile(credentials: ChannelCredentials): Promise<ChannelProfile>;
  fetchMedia(credentials: ChannelCredentials, limit?: number): Promise<MediaItem[]>;

  // Messaging
  sendDirectMessage(
    credentials: ChannelCredentials,
    recipientId: string,
    content: MessageContent
  ): Promise<SendResult>;
  replyToComment(
    credentials: ChannelCredentials,
    commentId: string,
    content: MessageContent
  ): Promise<SendResult>;

  // Webhooks
  verifyWebhookSignature(rawBody: string, signature: string, secret: string): boolean;
  parseWebhookEvent(payload: unknown): NormalizedEvent[];
  subscribeToWebhooks(credentials: ChannelCredentials, callbackUrl: string): Promise<void>;
}
