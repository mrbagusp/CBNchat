/**
 * lib/channels/instagram/adapter.ts
 * Implements ChannelAdapter for Instagram (Instagram Login API, 2024+).
 *
 * Phase 1: All methods return mock data — real Graph API calls added in Phase 4.
 * NOTE: Uses Instagram Login API, NOT the legacy Facebook Login → Page → IG flow.
 */

import type {
  ChannelAdapter,
  ChannelCredentials,
  ChannelProfile,
  MediaItem,
  MessageContent,
  NormalizedEvent,
  SendResult,
} from '../types';
import { MOCK_IG_MEDIA } from '@/lib/mock-data';

const IG_AUTH_BASE = 'https://www.instagram.com/oauth/authorize';
const IG_SCOPES = [
  'instagram_business_basic',
  'instagram_business_manage_messages',
  'instagram_business_manage_comments',
  'instagram_business_content_publish',
].join(',');

export class InstagramAdapter implements ChannelAdapter {
  readonly type = 'instagram' as const;
  readonly displayName = 'Instagram';
  readonly brandColor = '#E1306C';
  readonly available = true;

  // ---------------------------------------------------------------------------
  // OAuth
  // ---------------------------------------------------------------------------

  buildAuthUrl(state: string, redirectUri: string): string {
    const params = new URLSearchParams({
      client_id: process.env.META_INSTAGRAM_APP_ID ?? '',
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: IG_SCOPES,
      state,
    });
    return `${IG_AUTH_BASE}?${params.toString()}`;
  }

  async exchangeCode(code: string, _redirectUri: string): Promise<ChannelCredentials> {
    // Phase 4: real exchange. Phase 1 returns a mock credential.
    // NOTE: Real implementation POSTs to https://api.instagram.com/oauth/access_token
    // then GETs https://graph.instagram.com/access_token for long-lived token.
    void code;
    return {
      accessToken: 'mock_long_lived_token_ig',
      expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days
      scopes: IG_SCOPES.split(','),
    };
  }

  async refreshToken(credentials: ChannelCredentials): Promise<ChannelCredentials> {
    // Phase 4: GET https://graph.instagram.com/refresh_access_token
    return { ...credentials, expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000) };
  }

  async revokeAccess(_credentials: ChannelCredentials): Promise<void> {
    // Phase 4: Call Meta deauth endpoint
  }

  // ---------------------------------------------------------------------------
  // Profile
  // ---------------------------------------------------------------------------

  async fetchProfile(_credentials: ChannelCredentials): Promise<ChannelProfile> {
    // Phase 4: GET https://graph.instagram.com/me?fields=user_id,username,...
    return {
      externalId: 'mock_ig_user_id',
      username: 'superyouthgen',
      displayName: 'Superyouth Generation',
      profilePictureUrl: 'https://placehold.co/96x96?text=SY',
      followerCount: 124_800,
      mediaCount: 342,
      accountType: 'business',
    };
  }

  async fetchMedia(_credentials: ChannelCredentials, _limit = 24): Promise<MediaItem[]> {
    // Phase 4: GET https://graph.instagram.com/{ig-user-id}/media?fields=...
    // Phase 1: return mock media from seed data
    return MOCK_IG_MEDIA;
  }

  // ---------------------------------------------------------------------------
  // Messaging
  // ---------------------------------------------------------------------------

  async sendDirectMessage(
    _credentials: ChannelCredentials,
    recipientId: string,
    content: MessageContent
  ): Promise<SendResult> {
    // Phase 4: POST to Instagram Graph API /me/messages
    return {
      messageId: `mock_msg_${Date.now()}`,
      recipientId,
      timestamp: new Date(),
      status: 'sent',
    };
  }

  async replyToComment(
    _credentials: ChannelCredentials,
    commentId: string,
    content: MessageContent
  ): Promise<SendResult> {
    // Phase 4: POST to /{comment-id}/replies
    return {
      messageId: `mock_reply_${Date.now()}`,
      recipientId: commentId,
      timestamp: new Date(),
      status: 'sent',
    };
  }

  // ---------------------------------------------------------------------------
  // Webhooks
  // ---------------------------------------------------------------------------

  verifyWebhookSignature(rawBody: string, signature: string, secret: string): boolean {
    // Phase 4: HMAC-SHA256 verification
    // X-Hub-Signature-256: sha256={hash}
    void rawBody; void signature; void secret;
    return true; // allow all in Phase 1
  }

  parseWebhookEvent(payload: unknown): NormalizedEvent[] {
    // Phase 4: parse Meta webhook payload into NormalizedEvent[]
    void payload;
    return [];
  }

  async subscribeToWebhooks(
    _credentials: ChannelCredentials,
    _callbackUrl: string
  ): Promise<void> {
    // Phase 4: subscribe via Graph API
  }
}
