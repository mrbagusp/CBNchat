# Facebook Page Channel — Phase 7

**Status: Not implemented.**

This folder will contain `FacebookPageAdapter` implementing `ChannelAdapter` for Facebook Page support.

## Planned OAuth Scopes
- `pages_show_list`
- `pages_messaging`
- `pages_manage_engagement`
- `pages_read_engagement`
- `business_management`

## Planned Webhook Events
- `feed` — Page comments
- `messages` — Messenger DMs
- `messaging_postbacks`

## Environment Variables (Phase 7)
```
META_FACEBOOK_APP_ID=
META_FACEBOOK_APP_SECRET=
META_FACEBOOK_REDIRECT_URI=https://yourdomain.com/api/auth/facebook/callback
```

## Implementation Steps
1. Create `adapter.ts` implementing `ChannelAdapter`
2. Create `oauth.ts` for OAuth flow
3. Create `webhook.ts` for parsing Page events into `NormalizedEvent[]`
4. Register in `lib/channels/index.ts`
5. Enable "Continue with Facebook" button in `/login`
6. Enable Facebook tab in trigger modal
