/**
 * lib/store.ts
 * Zustand client state. Phase 4 will replace mock auth with Supabase Auth sessions.
 * Workspace selection and sidebar state persist to localStorage.
 */

import { create } from 'zustand'
import {
  DEMO_PROFILE,
  ORGANIZATION,
  WORKSPACES,
  DEFAULT_WORKSPACE_ID,
  type Profile,
  type Organization,
  type Workspace,
} from './mock-data'

interface AppState {
  // Auth (mocked — real Supabase auth in Phase 4)
  // TODO(Phase 4): Replace with real Supabase session. Remove demo defaults.
  user: Profile | null
  organization: Organization | null
  isAuthenticated: boolean

  // Actions
  login: (user: Profile) => void
  loginAsDemo: () => void
  logout: () => void

  // Active workspace
  activeWorkspaceId: string
  setActiveWorkspaceId: (id: string) => void
  getActiveWorkspace: () => Workspace | undefined

  // Sidebar collapse
  sidebarCollapsed: boolean
  toggleSidebar: () => void

  // Trial banner
  trialBannerDismissed: boolean
  dismissTrialBanner: () => void
}

export const useAppStore = create<AppState>()(
  (set, get) => ({
    // DEMO MODE: start already authenticated so there is zero async hydration.
    // No persist middleware = no localStorage read delay = no double-render flash.
    // TODO(Phase 4): Replace with real Supabase session check before production deploy.
    user: DEMO_PROFILE,
    organization: ORGANIZATION,
    isAuthenticated: true,

    login: (user) => set({ user, isAuthenticated: true, organization: ORGANIZATION }),
    loginAsDemo: () =>
      set({ user: DEMO_PROFILE, organization: ORGANIZATION, isAuthenticated: true }),
    logout: () => set({ user: null, organization: null, isAuthenticated: false }),

    activeWorkspaceId: DEFAULT_WORKSPACE_ID,
    setActiveWorkspaceId: (id) => set({ activeWorkspaceId: id }),
    getActiveWorkspace: () => WORKSPACES.find((w) => w.id === get().activeWorkspaceId),

    sidebarCollapsed: false,
    toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),

    trialBannerDismissed: false,
    dismissTrialBanner: () => set({ trialBannerDismissed: true }),
  })
)

/** Returns the currently active Workspace object */
export function useActiveWorkspace(): Workspace | undefined {
  return useAppStore((s) => WORKSPACES.find((w) => w.id === s.activeWorkspaceId))
}
