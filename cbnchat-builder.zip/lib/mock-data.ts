/**
 * lib/mock-data.ts
 * Seed data for Phase 1 preview. Follows the channel-agnostic DB schema —
 * no ig_* prefixes anywhere. A `channel` column signals the source platform.
 * In Phase 4+ this is replaced by real Supabase queries.
 */

export type ChannelType = 'instagram' | 'facebook_page' | 'tiktok' | 'whatsapp'
export type WorkspacePlan = 'free' | 'pro' | 'trial'
export type WorkspaceStatus = 'connected' | 'disconnected' | 'token_expired'
export type AutomationStatus = 'live' | 'draft' | 'paused'
export type ContactSource = 'comment' | 'dm' | 'story_reply' | 'manual'

export interface Organization {
  id: string
  name: string
  slug: string
  plan: WorkspacePlan
  logo_url: string | null
}

export interface Profile {
  id: string
  organization_id: string
  full_name: string
  avatar_url: string | null
  role: 'owner' | 'admin' | 'editor' | 'viewer'
  email: string
}

// Channel-agnostic workspace — no ig_* columns
export interface Workspace {
  id: string
  organization_id: string
  channel: ChannelType
  name: string
  external_id: string          // IG user_id | FB page_id | TikTok user_id
  external_username: string    // IG username | FB page name (may be empty for some channels)
  account_type: 'business' | 'creator' | 'page'
  profile_picture_url: string | null
  follower_count: number
  media_count: number
  status: WorkspaceStatus
  plan: WorkspacePlan
  connected_at: string | null
  trial_ends_at: string | null
}

// Channel-agnostic contact — no ig_* columns
export interface Contact {
  id: string
  workspace_id: string
  channel: ChannelType
  external_user_id: string     // IG user_id | FB PSID
  channel_username: string     // may be empty for FB (PSID doesn't expose username)
  full_name: string
  profile_pic_url: string | null
  first_seen_at: string
  last_seen_at: string
  tags: string[]
  subscribed: boolean
  source: ContactSource
}

export interface Automation {
  id: string
  workspace_id: string
  name: string
  status: AutomationStatus
  trigger_type: string
  folder_id: string | null
  stats: {
    triggered: number
    completed: number
    failed: number
  }
  created_at: string
}

export interface AutomationFolder {
  id: string
  workspace_id: string
  name: string
  sort_order: number
}

export interface AutomationRun {
  id: string
  automation_id: string
  automation_name: string
  status: 'running' | 'completed' | 'failed'
  started_at: string
  completed_at: string | null
  triggered_by: { comment_text?: string; post_id?: string }
}

export interface MockIgMedia {
  id: string
  workspace_id: string
  media_type: 'IMAGE' | 'VIDEO' | 'CAROUSEL_ALBUM'
  thumbnail_url: string
  caption: string
  timestamp: string
  permalink: string
  comment_count: number
}

export interface WebhookEndpoint {
  id: string
  organization_id: string
  name: string
  url: string
  events: string[]
  active: boolean
  last_triggered_at: string | null
  failure_count: number
}

// ─── ORGANIZATION ────────────────────────────────────────────────────────────

export const ORGANIZATION: Organization = {
  id: 'org-cbn-indonesia',
  name: 'CBN Indonesia',
  slug: 'cbn-indonesia',
  plan: 'pro',
  logo_url: null,
}

// ─── DEMO USER ────────────────────────────────────────────────────────────────

export const DEMO_PROFILE: Profile = {
  id: 'user-demo-001',
  organization_id: 'org-cbn-indonesia',
  full_name: 'Demo Admin',
  avatar_url: null,
  role: 'owner',
  email: 'demo@cbnchat.local',
}

// ─── WORKSPACES ───────────────────────────────────────────────────────────────

export const WORKSPACES: Workspace[] = [
  {
    id: 'ws-superyouth',
    organization_id: 'org-cbn-indonesia',
    channel: 'instagram',
    name: 'Superyouth Generation',
    external_id: 'ig-17841400001',
    external_username: 'superyouthgen',
    account_type: 'business',
    profile_picture_url: null,
    follower_count: 284500,
    media_count: 1243,
    status: 'connected',
    plan: 'pro',
    connected_at: '2026-01-10T08:30:00Z',
    trial_ends_at: '2026-04-19T23:59:59Z',
  },
  {
    id: 'ws-cahaya',
    organization_id: 'org-cbn-indonesia',
    channel: 'instagram',
    name: 'Cahaya Bagi Negeri',
    external_id: 'ig-17841400002',
    external_username: 'cahayabaginegeri',
    account_type: 'business',
    profile_picture_url: null,
    follower_count: 512000,
    media_count: 3412,
    status: 'connected',
    plan: 'pro',
    connected_at: '2026-01-15T09:00:00Z',
    trial_ends_at: null,
  },
  {
    id: 'ws-ingin-didoakan',
    organization_id: 'org-cbn-indonesia',
    channel: 'instagram',
    name: 'Ingin Didoakan',
    external_id: 'ig-17841400003',
    external_username: 'ingindidoakan',
    account_type: 'creator',
    profile_picture_url: null,
    follower_count: 98700,
    media_count: 445,
    status: 'connected',
    plan: 'pro',
    connected_at: '2026-02-01T10:00:00Z',
    trial_ends_at: null,
  },
  {
    id: 'ws-superbook',
    organization_id: 'org-cbn-indonesia',
    channel: 'instagram',
    name: 'Superbook Indonesia',
    external_id: 'ig-17841400004',
    external_username: 'superbookindonesia',
    account_type: 'business',
    profile_picture_url: null,
    follower_count: 156300,
    media_count: 892,
    status: 'disconnected',
    plan: 'free',
    connected_at: null,
    trial_ends_at: null,
  },
]

export const DEFAULT_WORKSPACE_ID = 'ws-superyouth'

// ─── AUTOMATION FOLDERS ───────────────────────────────────────────────────────

export const AUTOMATION_FOLDERS: AutomationFolder[] = [
  {
    id: 'folder-responden-carousel',
    workspace_id: 'ws-superyouth',
    name: 'RESPONDEN CAROUSEL',
    sort_order: 0,
  },
  {
    id: 'folder-responden-grafis',
    workspace_id: 'ws-superyouth',
    name: 'RESPONDEN GRAFIS',
    sort_order: 1,
  },
]

// ─── AUTOMATIONS ──────────────────────────────────────────────────────────────

export const AUTOMATIONS: Automation[] = [
  {
    id: 'auto-yesus-curhat',
    workspace_id: 'ws-superyouth',
    name: 'Yesus Curhat — Komentar → DM',
    status: 'live',
    trigger_type: 'post_comment',
    folder_id: 'folder-responden-carousel',
    stats: { triggered: 3241, completed: 3189, failed: 52 },
    created_at: '2026-02-10T10:00:00Z',
  },
  {
    id: 'auto-pdf-alkitab',
    workspace_id: 'ws-superyouth',
    name: 'Kirim PDF Alkitab Gratis',
    status: 'live',
    trigger_type: 'post_comment',
    folder_id: 'folder-responden-grafis',
    stats: { triggered: 1804, completed: 1790, failed: 14 },
    created_at: '2026-02-18T11:00:00Z',
  },
  {
    id: 'auto-ai-prayer',
    workspace_id: 'ws-superyouth',
    name: 'AI Prayer Request Handler',
    status: 'live',
    trigger_type: 'dm_message',
    folder_id: null,
    stats: { triggered: 945, completed: 931, failed: 14 },
    created_at: '2026-03-01T09:00:00Z',
  },
  {
    id: 'auto-easter-campaign',
    workspace_id: 'ws-superyouth',
    name: 'Paskah 2026 — Undangan Ibadah',
    status: 'draft',
    trigger_type: 'post_comment',
    folder_id: 'folder-responden-carousel',
    stats: { triggered: 0, completed: 0, failed: 0 },
    created_at: '2026-04-01T14:00:00Z',
  },
  {
    id: 'auto-story-reply',
    workspace_id: 'ws-superyouth',
    name: 'Story Reply — Link di Bio',
    status: 'paused',
    trigger_type: 'story_reply',
    folder_id: null,
    stats: { triggered: 512, completed: 499, failed: 13 },
    created_at: '2026-01-20T08:00:00Z',
  },
  {
    id: 'auto-cahaya-doa',
    workspace_id: 'ws-cahaya',
    name: 'Doa Pagi — Share & Tag',
    status: 'live',
    trigger_type: 'post_comment',
    folder_id: null,
    stats: { triggered: 7821, completed: 7804, failed: 17 },
    created_at: '2026-01-05T07:00:00Z',
  },
]

// ─── CONTACTS ─────────────────────────────────────────────────────────────────

const IG_USERNAMES = [
  'blessings_ribka', 'grace.putri', 'jonathan_setiawan', 'maria_siahaan',
  'yosua.ginting', 'esther_krisna', 'daniel.tampubolon', 'ruth_lestari',
  'samuel_kristian', 'deborah_marpaung', 'abraham_sirait', 'hanna.purnama',
  'isaac_wijaya', 'leah_manullang', 'joseph_sagala', 'naomi.simanjuntak',
  'caleb_hasibuan', 'miriam_sihotang', 'elijah_sembiring', 'priscilla.barus',
  'nathaniel_gurusinga', 'eve_silalahi', 'timothy_napitupulu', 'lydia_damanik',
  'stephen_aritonang', 'tabitha_saragih', 'paul_simorangkir', 'elizabeth_sagala',
  'barnabas_sinaga', 'phoebe_tarigan', 'cornelius_sijabat', 'dorcas_marbun',
  'titus_pakpahan', 'anna_sitanggang', 'silas_pardede', 'chloe_girsang',
  'luke_purba', 'eunice_pasaribu', 'mark_butarbutar', 'lois_lumban',
  'john_tobing', 'rachel_manurung', 'peter_sianturi', 'sarah_panggabean',
  'james_gultom', 'mary_simarmata', 'andrew_tambunan', 'martha_sinurat',
  'thomas_nababan', 'susanna_hutasoit',
]

const FULL_NAMES = [
  'Ribka Blessing', 'Putri Grace', 'Jonathan Setiawan', 'Maria Siahaan',
  'Yosua Ginting', 'Esther Krisna', 'Daniel Tampubolon', 'Ruth Lestari',
  'Samuel Kristian', 'Deborah Marpaung', 'Abraham Sirait', 'Hanna Purnama',
  'Isaac Wijaya', 'Leah Manullang', 'Joseph Sagala', 'Naomi Simanjuntak',
  'Caleb Hasibuan', 'Miriam Sihotang', 'Elijah Sembiring', 'Priscilla Barus',
  'Nathaniel Gurusinga', 'Eve Silalahi', 'Timothy Napitupulu', 'Lydia Damanik',
  'Stephen Aritonang', 'Tabitha Saragih', 'Paul Simorangkir', 'Elizabeth Sagala',
  'Barnabas Sinaga', 'Phoebe Tarigan', 'Cornelius Sijabat', 'Dorcas Marbun',
  'Titus Pakpahan', 'Anna Sitanggang', 'Silas Pardede', 'Chloe Girsang',
  'Luke Purba', 'Eunice Pasaribu', 'Mark Butarbutar', 'Lois Lumban',
  'John Tobing', 'Rachel Manurung', 'Peter Sianturi', 'Sarah Panggabean',
  'James Gultom', 'Mary Simarmata', 'Andrew Tambunan', 'Martha Sinurat',
  'Thomas Nababan', 'Susanna Hutasoit',
]

const TAG_POOL: string[][] = [
  ['new_lead', 'yesus_curhat'],
  ['doa', 'new_lead'],
  ['paid_event'],
  ['yesus_curhat', 'doa'],
  ['new_lead'],
  ['paid_event', 'new_lead'],
  [],
  ['doa'],
  ['yesus_curhat'],
  ['new_lead', 'paid_event'],
]

const SOURCES: ContactSource[] = ['comment', 'dm', 'story_reply', 'manual', 'comment', 'comment', 'dm', 'comment']

function daysAgo(n: number): string {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return d.toISOString()
}

export const CONTACTS: Contact[] = IG_USERNAMES.map((username, i) => ({
  id: `contact-${String(i).padStart(3, '0')}`,
  workspace_id: 'ws-superyouth',
  channel: 'instagram' as ChannelType,
  external_user_id: `ig-contact-${1000 + i}`,
  channel_username: username,
  full_name: FULL_NAMES[i],
  profile_pic_url: null,
  first_seen_at: daysAgo(30 - (i % 30)),
  last_seen_at: daysAgo(i % 10),
  tags: TAG_POOL[i % TAG_POOL.length],
  subscribed: i % 7 !== 0,
  source: SOURCES[i % SOURCES.length],
}))

// ─── AUTOMATION RUNS (last 7 days) ────────────────────────────────────────────

const RUN_AUTO_MAP: Array<{ id: string; name: string }> = [
  { id: 'auto-yesus-curhat', name: 'Yesus Curhat — Komentar → DM' },
  { id: 'auto-pdf-alkitab', name: 'Kirim PDF Alkitab Gratis' },
  { id: 'auto-ai-prayer', name: 'AI Prayer Request Handler' },
]

const RUN_COMMENTS = [
  'info dong', 'tolong doakan saya kak', 'minta link dong', 'doa ya kak', 'info please',
  'amen!', 'tolong kirimin pdf nya', 'boleh minta doanya?', 'linknya dong', 'amin 🙏',
]

export const AUTOMATION_RUNS: AutomationRun[] = Array.from({ length: 20 }, (_, i) => {
  const auto = RUN_AUTO_MAP[i % 3]
  const failed = i % 5 === 4
  return {
    id: `run-${String(i).padStart(3, '0')}`,
    automation_id: auto.id,
    automation_name: auto.name,
    status: failed ? 'failed' : 'completed',
    started_at: daysAgo(i % 7),
    completed_at: failed ? null : daysAgo(i % 7),
    triggered_by: {
      post_id: `ig_post_${1000 + i}`,
      comment_text: RUN_COMMENTS[i % RUN_COMMENTS.length],
    },
  }
})

// ─── MOCK IG MEDIA ────────────────────────────────────────────────────────────
// Mirrors the 6 Manychat posts from the spec

export const MOCK_IG_MEDIA: MockIgMedia[] = [
  {
    id: 'media-001',
    workspace_id: 'ws-superyouth',
    media_type: 'CAROUSEL_ALBUM',
    thumbnail_url: 'https://placehold.co/400x400?text=DULU+MENGHINA+YESUS+kini+berubah+jadi+pelayan+Tuhan+carousel+post+orange+background',
    caption: 'DULU MENGHINA YESUS... Kisah hidup yang berubah karena kasih Tuhan. Komentar "INFO" untuk info selengkapnya 👇',
    timestamp: daysAgo(5),
    permalink: 'https://www.instagram.com/p/mock001/',
    comment_count: 847,
  },
  {
    id: 'media-002',
    workspace_id: 'ws-superyouth',
    media_type: 'VIDEO',
    thumbnail_url: 'https://placehold.co/400x400?text=Yesus+itu+di+hidup+kamu+reel+video+thumbnail+blue+gradient+background',
    caption: 'Yesus itu di hidup kamu... bahkan saat kamu tidak menyadarinya. Tonton sampai habis! 🙏',
    timestamp: daysAgo(8),
    permalink: 'https://www.instagram.com/reel/mock002/',
    comment_count: 2341,
  },
  {
    id: 'media-003',
    workspace_id: 'ws-superyouth',
    media_type: 'VIDEO',
    thumbnail_url: 'https://placehold.co/400x400?text=Apa+Yang+Membuat+Dade+Yosef+Bertahan+video+thumbnail+portrait+interview',
    caption: 'Apa Yang Membuat Dade Yosef Bertahan di tengah badai hidup? Kisah nyata yang akan menyentuh hatimu.',
    timestamp: daysAgo(12),
    permalink: 'https://www.instagram.com/reel/mock003/',
    comment_count: 1562,
  },
  {
    id: 'media-004',
    workspace_id: 'ws-superyouth',
    media_type: 'CAROUSEL_ALBUM',
    thumbnail_url: 'https://placehold.co/400x400?text=YANG+MENYALIBKAN+YESUS+infographic+carousel+dark+blue+typography',
    caption: 'YANG MENYALIBKAN YESUS — siapakah yang bertanggung jawab? Telusuri fakta sejarah bersama kami.',
    timestamp: daysAgo(15),
    permalink: 'https://www.instagram.com/p/mock004/',
    comment_count: 3209,
  },
  {
    id: 'media-005',
    workspace_id: 'ws-superyouth',
    media_type: 'VIDEO',
    thumbnail_url: 'https://placehold.co/400x400?text=Alkitabku+Dirobek+emotional+testimony+video+thumbnail+warm+lighting',
    caption: 'Alkitabku Dirobek... Penganiayaan nyata yang dialami saudara seiman kita. Doakan mereka.',
    timestamp: daysAgo(20),
    permalink: 'https://www.instagram.com/reel/mock005/',
    comment_count: 4817,
  },
  {
    id: 'media-006',
    workspace_id: 'ws-superyouth',
    media_type: 'CAROUSEL_ALBUM',
    thumbnail_url: 'https://placehold.co/400x400?text=Yesus+tidak+di+salib+debunking+misconception+carousel+white+red+text',
    caption: 'Yesus tidak di salib...? Menjawab klaim yang sering dipertanyakan dengan fakta dan Firman Tuhan.',
    timestamp: daysAgo(25),
    permalink: 'https://www.instagram.com/p/mock006/',
    comment_count: 5634,
  },
]

// ─── WEBHOOK ENDPOINT ─────────────────────────────────────────────────────────

export const WEBHOOK_ENDPOINTS: WebhookEndpoint[] = [
  {
    id: 'webhook-crm-001',
    organization_id: 'org-cbn-indonesia',
    name: 'CRM Webhook (Example)',
    url: 'https://example.com/crm-webhook',
    events: ['contact.created', 'automation.completed', 'message.received'],
    active: false,
    last_triggered_at: null,
    failure_count: 0,
  },
]

// ─── DASHBOARD STATS (7-day window, per workspace) ────────────────────────────

export function getDashboardStats(workspaceId: string) {
  if (workspaceId === 'ws-superyouth') {
    return {
      triggered: { value: 1284, change: +12.4 },
      newContacts: { value: 93, change: +8.1 },
      messagesSent: { value: 2671, change: +5.7 },
      crmLeads: { value: 38, change: +22.0 },
      sparklines: {
        triggered: [84, 120, 198, 164, 201, 287, 230],
        newContacts: [8, 12, 15, 9, 18, 21, 10],
        messagesSent: [210, 310, 450, 380, 420, 591, 310],
        crmLeads: [3, 5, 7, 4, 6, 9, 4],
      },
    }
  }
  if (workspaceId === 'ws-cahaya') {
    return {
      triggered: { value: 3812, change: +18.2 },
      newContacts: { value: 211, change: +14.5 },
      messagesSent: { value: 7204, change: +9.1 },
      crmLeads: { value: 84, change: +31.0 },
      sparklines: {
        triggered: [420, 510, 690, 580, 712, 450, 450],
        newContacts: [24, 28, 38, 30, 41, 32, 18],
        messagesSent: [880, 1020, 1310, 1080, 1400, 890, 624],
        crmLeads: [9, 12, 16, 11, 18, 13, 5],
      },
    }
  }
  return {
    triggered: { value: 0, change: 0 },
    newContacts: { value: 0, change: 0 },
    messagesSent: { value: 0, change: 0 },
    crmLeads: { value: 0, change: 0 },
    sparklines: {
      triggered: [0, 0, 0, 0, 0, 0, 0],
      newContacts: [0, 0, 0, 0, 0, 0, 0],
      messagesSent: [0, 0, 0, 0, 0, 0, 0],
      crmLeads: [0, 0, 0, 0, 0, 0, 0],
    },
  }
}
