/**
 * lib/demo/session.ts
 * Demo mode flag and demo user object.
 *
 * DEMO_MODE = true bypasses Supabase auth entirely and uses mock fixtures.
 * TODO(Phase 4): Remove this file and replace all DEMO_MODE checks with real
 * Supabase Auth sessions before production deploy.
 */

export const DEMO_MODE =
  process.env.NEXT_PUBLIC_DEMO_MODE === 'true'

export const demoUser = {
  id: 'demo-user-id',
  email: 'demo@cbnchat.local',
  full_name: 'Demo User',
  avatar_url: 'https://api.dicebear.com/7.x/initials/svg?seed=Demo%20User',
  role: 'owner' as const,
  organization_id: 'demo-org-id',
}
