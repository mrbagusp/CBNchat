/**
 * lib/demo/fixtures.ts
 * Re-exports all seed data from mock-data.ts as "demo fixtures".
 * Pages read from these when DEMO_MODE is true.
 *
 * TODO(Phase 4): Replace imports of this file with real Supabase query hooks.
 */

export {
  ORGANIZATION as demoOrganization,
  DEMO_PROFILE as demoProfile,
  WORKSPACES as demoWorkspaces,
  DEFAULT_WORKSPACE_ID as demoDefaultWorkspaceId,
  AUTOMATION_FOLDERS as demoFolders,
  AUTOMATIONS as demoAutomations,
  AUTOMATION_RUNS as demoAutomationRuns,
  CONTACTS as demoContacts,
  MOCK_IG_MEDIA as demoMedia,
  WEBHOOK_ENDPOINTS as demoWebhookEndpoints,
  getDashboardStats,
} from '@/lib/mock-data'

import type {
  Organization,
  Profile,
  Workspace,
  Automation,
  AutomationFolder,
  AutomationRun,
  Contact,
  MockIgMedia,
  WebhookEndpoint,
} from '@/lib/mock-data'

// 7-day sparkline stats — pre-computed so pages don't need to aggregate
export const demoStats = {
  triggered:     { value: 1284, change: '+12%', sparkline: [84, 120, 198, 164, 201, 287, 230] },
  new_contacts:  { value: 93,   change: '+8%',  sparkline: [8, 12, 15, 9, 18, 21, 10] },
  messages_sent: { value: 2671, change: '+23%', sparkline: [210, 310, 450, 380, 420, 591, 310] },
  crm_leads:     { value: 38,   change: '+15%', sparkline: [3, 5, 7, 4, 6, 9, 4] },
}

export type {
  Organization,
  Profile,
  Workspace,
  Automation,
  AutomationFolder,
  AutomationRun,
  Contact,
  MockIgMedia,
  WebhookEndpoint,
}
