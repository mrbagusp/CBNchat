-- CBNchat Phase 1 — Seed Data
-- Run AFTER 001_schema.sql.
-- NOTE: The demo auth user must be created separately via the Node seed script
-- (scripts/seed.ts) because SQL cannot call supabase.auth.admin.createUser().
-- This file seeds all application data using stable UUIDs.

-- ────────────────────────────────────────────────────────────────────────────
-- Stable UUIDs (deterministic so re-running is idempotent)
-- ────────────────────────────────────────────────────────────────────────────
-- org:       'a1b2c3d4-0000-0000-0000-000000000001'
-- user:      'a1b2c3d4-0000-0000-0000-000000000002'  (created by seed.ts)
-- ws-supery: 'a1b2c3d4-0000-0000-0001-000000000001'
-- ws-cahaya: 'a1b2c3d4-0000-0000-0001-000000000002'
-- ws-superb: 'a1b2c3d4-0000-0000-0001-000000000003'
-- ws-ingin:  'a1b2c3d4-0000-0000-0001-000000000004'

-- ────────────────────────────────────────────────────────────────────────────
-- Organization
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO organizations (id, name, slug, plan) VALUES
  ('a1b2c3d4-0000-0000-0000-000000000001', 'CBN Indonesia', 'cbn-indonesia', 'pro')
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────────────────────
-- Profile (auth user created by seed.ts first)
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO profiles (id, organization_id, full_name, role) VALUES
  ('a1b2c3d4-0000-0000-0000-000000000002',
   'a1b2c3d4-0000-0000-0000-000000000001',
   'Demo User', 'owner')
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────────────────────
-- Workspaces (all Instagram in Phase 1)
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO workspaces (id, organization_id, channel, name, external_id, external_username,
  account_type, profile_picture_url, follower_count, media_count, status, connected_at) VALUES
  ('a1b2c3d4-0000-0000-0001-000000000001',
   'a1b2c3d4-0000-0000-0000-000000000001',
   'instagram', 'Superyouth Generation', 'ig_17841400001', 'superyouthgen',
   'business', 'https://api.dicebear.com/7.x/shapes/svg?seed=superyouthgen',
   284500, 1243, 'connected', now() - interval '90 days'),
  ('a1b2c3d4-0000-0000-0001-000000000002',
   'a1b2c3d4-0000-0000-0000-000000000001',
   'instagram', 'Cahaya Bagi Negeri Indonesia', 'ig_17841400002', 'cahayabaginegeri',
   'business', 'https://api.dicebear.com/7.x/shapes/svg?seed=cahayabaginegeri',
   512000, 3412, 'connected', now() - interval '60 days'),
  ('a1b2c3d4-0000-0000-0001-000000000003',
   'a1b2c3d4-0000-0000-0000-000000000001',
   'instagram', 'Superbook Indonesia', 'ig_17841400003', 'superbookindonesia',
   'business', 'https://api.dicebear.com/7.x/shapes/svg?seed=superbookindonesia',
   45200, 892, 'connected', now() - interval '30 days'),
  ('a1b2c3d4-0000-0000-0001-000000000004',
   'a1b2c3d4-0000-0000-0000-000000000001',
   'instagram', 'Ingin Didoakan', 'ig_17841400004', 'ingindidoakan',
   'creator', 'https://api.dicebear.com/7.x/shapes/svg?seed=ingindidoakan',
   98700, 445, 'connected', now() - interval '14 days')
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────────────────────
-- Automation folders (for Superyouth Generation)
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO automation_folders (id, workspace_id, name, sort_order) VALUES
  ('a1b2c3d4-0000-0000-0002-000000000001', 'a1b2c3d4-0000-0000-0001-000000000001', 'RESPONDEN CAROUSEL', 0),
  ('a1b2c3d4-0000-0000-0002-000000000002', 'a1b2c3d4-0000-0000-0001-000000000001', 'RESPONDEN GRAFIS', 1)
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────────────────────
-- Automations (3 — live + draft + ai)
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO automations (id, workspace_id, folder_id, name, status, trigger_type, trigger_config, stats) VALUES
  ('a1b2c3d4-0000-0000-0003-000000000001',
   'a1b2c3d4-0000-0000-0001-000000000001',
   'a1b2c3d4-0000-0000-0002-000000000001',
   'Auto-DM from new comments', 'live', 'post_comment',
   '{"post_ids":["all"],"keywords":["info","daftar","link","download"],"match":"contains"}',
   '{"triggered":342,"completed":298,"failed":44}'),
  ('a1b2c3d4-0000-0000-0003-000000000002',
   'a1b2c3d4-0000-0000-0001-000000000001',
   'a1b2c3d4-0000-0000-0002-000000000002',
   'Story reply → offer ebook', 'draft', 'story_reply',
   '{"keywords":[],"match":"any"}',
   '{"triggered":0,"completed":0,"failed":0}'),
  ('a1b2c3d4-0000-0000-0003-000000000003',
   'a1b2c3d4-0000-0000-0001-000000000001',
   'a1b2c3d4-0000-0000-0002-000000000001',
   'AI reply for prayer requests', 'live', 'post_comment',
   '{"post_ids":["all"],"keywords":["doa","doakan","prayer","bantuan"],"match":"contains"}',
   '{"triggered":87,"completed":81,"failed":6}')
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────────────────────
-- Contacts (50 across 4 workspaces)
-- ────────────────────────────────────────────────────────────────────────────
DO $$
DECLARE
  usernames TEXT[] := ARRAY[
    'yusuf.kristian','maria_doa','hamba_tuhan23','grace_indonesia','samuel.prasetyo',
    'ruth_blessed','agung.sitorus','esther.wijaya','daniel.siagian','naomi.lestari',
    'timotius.ginting','priscilla.hutabarat','barnabas.sihombing','lydia.purba','yunus.manurung',
    'deborah.tampubolon','ezra.simbolon','rahel.panjaitan','musa.sirait','anna.hutapea',
    'abigail.nainggolan','daud.sinaga','salomo.silaban','yeremia.nababan','hana.sipayung',
    'petrus.lumbantobing','paulus.sagala','yohanes_cbn','lukas.saragih','markus.pasaribu',
    'ayub.siahaan','rut_berkat','elia.pakpahan','elisa.situmorang','yesaya.pardede',
    'amos.siburian','hosea.manullang','micha.sinurat','naum.banjarnahor','habakuk.sijabat',
    'malakhi.tobing','nehemia.simanjuntak','ezekiel.simatupang','yoel.napitupulu','obaja.tambunan',
    'yudit.saragi','yusuf_muda','maria_magdalena_id','ester_cantik','kristus_hidup'
  ];
  full_names TEXT[] := ARRAY[
    'Yusuf Kristian','Maria Doa','Hamba Tuhan','Grace Indonesia','Samuel Prasetyo',
    'Ruth Blessed','Agung Sitorus','Esther Wijaya','Daniel Siagian','Naomi Lestari',
    'Timotius Ginting','Priscilla Hutabarat','Barnabas Sihombing','Lydia Purba','Yunus Manurung',
    'Deborah Tampubolon','Ezra Simbolon','Rahel Panjaitan','Musa Sirait','Anna Hutapea',
    'Abigail Nainggolan','Daud Sinaga','Salomo Silaban','Yeremia Nababan','Hana Sipayung',
    'Petrus Lumbantobing','Paulus Sagala','Yohanes CBN','Lukas Saragih','Markus Pasaribu',
    'Ayub Siahaan','Rut Berkat','Elia Pakpahan','Elisa Situmorang','Yesaya Pardede',
    'Amos Siburian','Hosea Manullang','Micha Sinurat','Naum Banjarnahor','Habakuk Sijabat',
    'Malakhi Tobing','Nehemia Simanjuntak','Ezekiel Simatupang','Yoel Napitupulu','Obaja Tambunan',
    'Yudit Saragi','Yusuf Muda','Maria Magdalena','Ester Cantik','Kristus Hidup'
  ];
  ws_ids UUID[] := ARRAY[
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000004'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000004'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000004'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000004'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000004'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000004'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000002'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000003'::UUID,
    'a1b2c3d4-0000-0000-0001-000000000001'::UUID
  ];
  tags_pool TEXT[][] := ARRAY[
    ARRAY['new_lead'], ARRAY['doa'], ARRAY['yesus_curhat'], ARRAY['paid_event'],
    ARRAY['new_lead','doa'], ARRAY['yesus_curhat','new_lead'], ARRAY['paid_event','doa'],
    ARRAY['new_lead'], ARRAY['doa','paid_event']
  ];
  sources TEXT[] := ARRAY['comment','dm','story_reply','comment','comment','dm','story_reply'];
  i INT;
BEGIN
  FOR i IN 1..50 LOOP
    INSERT INTO contacts (
      workspace_id, channel, external_user_id, channel_username, full_name,
      profile_pic_url, tags, subscribed, source,
      first_seen_at, last_seen_at
    ) VALUES (
      ws_ids[i],
      'instagram',
      'ig_contact_' || (1000 + i)::TEXT,
      usernames[i],
      full_names[i],
      'https://api.dicebear.com/7.x/thumbs/svg?seed=' || usernames[i],
      tags_pool[((i-1) % array_length(tags_pool,1)) + 1],
      (i % 7 != 0),
      sources[((i-1) % array_length(sources,1)) + 1],
      now() - (((30 - (i % 30)) || ' days')::INTERVAL),
      now() - (((i % 10) || ' days')::INTERVAL)
    ) ON CONFLICT (workspace_id, external_user_id) DO NOTHING;
  END LOOP;
END;
$$;

-- ────────────────────────────────────────────────────────────────────────────
-- Automation runs (20 across last 7 days)
-- ────────────────────────────────────────────────────────────────────────────
DO $$
DECLARE
  automation_ids UUID[] := ARRAY[
    'a1b2c3d4-0000-0000-0003-000000000001'::UUID,
    'a1b2c3d4-0000-0000-0003-000000000003'::UUID
  ];
  statuses TEXT[] := ARRAY['completed','completed','completed','completed','failed'];
  i INT;
  hrs_ago INT;
BEGIN
  FOR i IN 1..20 LOOP
    hrs_ago := (i * 8) % 168;  -- spread over 7 days (168 hours)
    INSERT INTO automation_runs (
      automation_id, status, started_at, completed_at,
      triggered_by, step_log
    ) VALUES (
      automation_ids[((i-1) % 2) + 1],
      statuses[((i-1) % array_length(statuses,1)) + 1],
      now() - ((hrs_ago || ' hours')::INTERVAL),
      now() - ((hrs_ago || ' hours')::INTERVAL) + interval '2 seconds',
      ('{"post_id":"ig_post_' || i::TEXT || '","comment_text":"info dong"}')::JSONB,
      '[{"step":"trigger","status":"ok"},{"step":"send_dm","status":"ok"}]'::JSONB
    );
  END LOOP;
END;
$$;

-- ────────────────────────────────────────────────────────────────────────────
-- Messages (100 outbound DMs)
-- ────────────────────────────────────────────────────────────────────────────
DO $$
DECLARE
  i INT;
  hrs_ago INT;
BEGIN
  FOR i IN 1..100 LOOP
    hrs_ago := (i * 1) % 168;
    INSERT INTO messages (
      workspace_id, channel, direction, type,
      external_message_id, content, status, created_at
    ) VALUES (
      'a1b2c3d4-0000-0000-0001-000000000001',
      'instagram', 'out', 'dm',
      'ig_msg_' || (10000 + i)::TEXT,
      CASE (i % 5)
        WHEN 0 THEN 'Halo! Terima kasih sudah berkomentar. DM ini untuk info lebih lanjut ya!'
        WHEN 1 THEN 'Hai kak! Kami sudah kirimkan link-nya ke DM kamu. Tuhan memberkati!'
        WHEN 2 THEN 'Salam kasih! Silahkan cek DM dari kami untuk info lengkapnya.'
        WHEN 3 THEN 'Terima kasih sudah tertarik! Link ebook sudah kami kirimkan ke DM ini.'
        ELSE 'Halo! Tim kami akan segera menghubungi kamu. GBU!'
      END,
      CASE (i % 10) WHEN 0 THEN 'failed' ELSE 'delivered' END,
      now() - ((hrs_ago || ' hours')::INTERVAL)
    );
  END LOOP;
END;
$$;

-- ────────────────────────────────────────────────────────────────────────────
-- Webhook endpoint
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO webhook_endpoints (id, organization_id, name, url, secret, events, active) VALUES
  ('a1b2c3d4-0000-0000-0004-000000000001',
   'a1b2c3d4-0000-0000-0000-000000000001',
   'CBN CRM',
   'https://example.com/crm-webhook',
   'whsec_placeholder_secret_change_me',
   ARRAY['contact.created','contact.tagged','automation.completed','message.received'],
   false)
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────────────────────
-- AI Config for Superyouth Generation
-- ────────────────────────────────────────────────────────────────────────────
INSERT INTO ai_configs (workspace_id, enabled, system_prompt, model, temperature, max_tokens, fallback_message) VALUES
  ('a1b2c3d4-0000-0000-0001-000000000001',
   true,
   'You are a friendly assistant for Superyouth Generation, a Christian youth media community in Indonesia. Respond to Instagram comments in Bahasa Indonesia, warmly and concisely (max 2 sentences). Always invite the commenter to DM us for prayer requests or to join our WhatsApp community. Never discuss political or divisive topics.',
   'gpt-4o-mini',
   0.7,
   300,
   'Halo! Terima kasih sudah berkomentar. Tim kami akan segera membalas pesanmu. Tuhan memberkati!')
ON CONFLICT (workspace_id) DO NOTHING;
