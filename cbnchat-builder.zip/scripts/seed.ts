/**
 * scripts/seed.ts
 * Creates the demo auth user in Supabase Auth, then runs the seed SQL.
 * Usage: npx tsx scripts/seed.ts
 * Requires: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in environment.
 */
import { createClient } from '@supabase/supabase-js'
import { readFileSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error('Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY')
  process.exit(1)
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
})

async function main() {
  console.log('CBNchat seed script starting...')

  // 1. Create demo auth user (stable UUID)
  const DEMO_USER_ID = 'a1b2c3d4-0000-0000-0000-000000000002'
  const { data: existingUser } = await supabase.auth.admin.getUserById(DEMO_USER_ID)

  if (!existingUser.user) {
    console.log('Creating demo auth user...')
    const { error } = await supabase.auth.admin.createUser({
      id: DEMO_USER_ID,
      email: 'demo@cbnchat.local',
      password: 'demo1234',
      email_confirm: true,
      user_metadata: { full_name: 'Demo User' },
    })
    if (error) {
      console.error('Failed to create demo user:', error.message)
      process.exit(1)
    }
    console.log('Demo user created: demo@cbnchat.local / demo1234')
  } else {
    console.log('Demo user already exists, skipping.')
  }

  // 2. Run seed SQL (002_seed.sql)
  const seedSQL = readFileSync(join(__dirname, '002_seed.sql'), 'utf8')
  // Split on statement boundaries (semicolons not inside $$ blocks)
  // NOTE: For simplicity we use Supabase's rpc or run it via the Dashboard.
  // The SQL file is safe to run directly in the Supabase SQL Editor.
  console.log('')
  console.log('Auth user ready. Now run 002_seed.sql in your Supabase SQL Editor.')
  console.log('Or use the Supabase CLI: supabase db reset --linked')
  console.log('')
  console.log('Done!')
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
