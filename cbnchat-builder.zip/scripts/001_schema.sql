-- CBNchat Phase 1 — Database Schema
-- Channel-agnostic design: no ig_* prefixes anywhere.
-- Run via: Supabase Dashboard → SQL Editor → paste and run.

-- ────────────────────────────────────────────────────────────────────────────
-- Helpers
-- ────────────────────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Auto-update updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- ────────────────────────────────────────────────────────────────────────────
-- Organizations (tenant root)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS organizations (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  slug        TEXT UNIQUE NOT NULL,
  plan        TEXT NOT NULL DEFAULT 'free',
  logo_url    TEXT,
  settings    JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_organizations_updated_at
  BEFORE UPDATE ON organizations
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at();

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "org_select" ON organizations FOR SELECT
  USING (id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid()
  ));
CREATE POLICY "org_update" ON organizations FOR UPDATE
  USING (id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid()
      AND role IN ('owner', 'admin')
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Profiles (extends Supabase auth.users)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  organization_id UUID NOT NULL REFERENCES organizations ON DELETE CASCADE,
  full_name       TEXT,
  avatar_url      TEXT,
  role            TEXT NOT NULL DEFAULT 'viewer'
                    CHECK (role IN ('owner','admin','editor','viewer')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at();

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profile_select" ON profiles FOR SELECT
  USING (organization_id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid()
  ));
CREATE POLICY "profile_update_own" ON profiles FOR UPDATE
  USING (id = auth.uid());

-- ────────────────────────────────────────────────────────────────────────────
-- Workspaces (one per social account / page)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS workspaces (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id       UUID NOT NULL REFERENCES organizations ON DELETE CASCADE,
  channel               TEXT NOT NULL CHECK (channel IN ('instagram','facebook_page','tiktok','whatsapp')),
  name                  TEXT NOT NULL,
  external_id           TEXT,            -- IG user_id | FB page_id | etc.
  external_username     TEXT,            -- IG username | FB page name
  account_type          TEXT,            -- 'business' | 'creator' | 'page'
  profile_picture_url   TEXT,
  follower_count        INT DEFAULT 0,
  media_count           INT DEFAULT 0,
  credentials           JSONB,           -- encrypted in production via pgsodium
  status                TEXT NOT NULL DEFAULT 'disconnected'
                          CHECK (status IN ('connected','disconnected','token_expired','revoked')),
  connected_at          TIMESTAMPTZ,
  webhook_subscribed    BOOLEAN NOT NULL DEFAULT false,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (channel, external_id)
);
CREATE TRIGGER trg_workspaces_updated_at
  BEFORE UPDATE ON workspaces
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at();

ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspaces_org" ON workspaces FOR ALL
  USING (organization_id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Contacts (end-users who interacted with our accounts)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contacts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id      UUID NOT NULL REFERENCES workspaces ON DELETE CASCADE,
  channel           TEXT NOT NULL,
  external_user_id  TEXT NOT NULL,   -- IG user_id | FB PSID
  channel_username  TEXT,
  full_name         TEXT,
  profile_pic_url   TEXT,
  first_seen_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  tags              TEXT[] NOT NULL DEFAULT '{}',
  custom_fields     JSONB NOT NULL DEFAULT '{}',
  subscribed        BOOLEAN NOT NULL DEFAULT true,
  source            TEXT CHECK (source IN ('comment','dm','story_reply','manual')),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, external_user_id)
);
CREATE INDEX ON contacts (workspace_id, channel, last_seen_at DESC);
CREATE TRIGGER trg_contacts_updated_at
  BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at();

ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "contacts_org" ON contacts FOR ALL
  USING (workspace_id IN (
    SELECT w.id FROM workspaces w
    JOIN profiles p ON p.organization_id = w.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Automation folders
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS automation_folders (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces ON DELETE CASCADE,
  name         TEXT NOT NULL,
  sort_order   INT NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE automation_folders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "folders_org" ON automation_folders FOR ALL
  USING (workspace_id IN (
    SELECT w.id FROM workspaces w
    JOIN profiles p ON p.organization_id = w.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Automations
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS automations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id    UUID NOT NULL REFERENCES workspaces ON DELETE CASCADE,
  folder_id       UUID REFERENCES automation_folders ON DELETE SET NULL,
  name            TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft','live','paused')),
  trigger_type    TEXT,
  trigger_config  JSONB,
  flow_definition JSONB,
  created_by      UUID REFERENCES profiles ON DELETE SET NULL,
  stats           JSONB NOT NULL DEFAULT '{"triggered":0,"completed":0,"failed":0}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON automations (workspace_id, status);
CREATE TRIGGER trg_automations_updated_at
  BEFORE UPDATE ON automations
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at();

ALTER TABLE automations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "automations_org" ON automations FOR ALL
  USING (workspace_id IN (
    SELECT w.id FROM workspaces w
    JOIN profiles p ON p.organization_id = w.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Automation runs (per-execution log)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS automation_runs (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  automation_id  UUID NOT NULL REFERENCES automations ON DELETE CASCADE,
  contact_id     UUID REFERENCES contacts ON DELETE SET NULL,
  triggered_by   JSONB,
  status         TEXT NOT NULL CHECK (status IN ('running','completed','failed')),
  step_log       JSONB NOT NULL DEFAULT '[]',
  error          TEXT,
  started_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON automation_runs (automation_id, started_at DESC);
ALTER TABLE automation_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "runs_org" ON automation_runs FOR ALL
  USING (automation_id IN (
    SELECT a.id FROM automations a
    JOIN workspaces w ON w.id = a.workspace_id
    JOIN profiles p ON p.organization_id = w.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Messages (all inbound + outbound, across channels)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id         UUID NOT NULL REFERENCES workspaces ON DELETE CASCADE,
  contact_id           UUID REFERENCES contacts ON DELETE SET NULL,
  channel              TEXT NOT NULL,
  direction            TEXT NOT NULL CHECK (direction IN ('in','out')),
  type                 TEXT CHECK (type IN ('dm','comment_reply','story_reply','messenger')),
  external_message_id  TEXT,
  external_post_id     TEXT,
  external_comment_id  TEXT,
  content              TEXT,
  media                JSONB,
  automation_run_id    UUID REFERENCES automation_runs ON DELETE SET NULL,
  status               TEXT CHECK (status IN ('queued','sent','delivered','failed')),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON messages (workspace_id, channel, created_at DESC);
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "messages_org" ON messages FOR ALL
  USING (workspace_id IN (
    SELECT w.id FROM workspaces w
    JOIN profiles p ON p.organization_id = w.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Outbound webhook endpoints (to CRM / external systems)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS webhook_endpoints (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id   UUID NOT NULL REFERENCES organizations ON DELETE CASCADE,
  name              TEXT NOT NULL,
  url               TEXT NOT NULL,
  secret            TEXT,
  events            TEXT[] NOT NULL DEFAULT '{}',
  active            BOOLEAN NOT NULL DEFAULT true,
  last_triggered_at TIMESTAMPTZ,
  failure_count     INT NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE webhook_endpoints ENABLE ROW LEVEL SECURITY;
CREATE POLICY "endpoints_org" ON webhook_endpoints FOR ALL
  USING (organization_id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- Webhook delivery log
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  endpoint_id    UUID NOT NULL REFERENCES webhook_endpoints ON DELETE CASCADE,
  event_type     TEXT NOT NULL,
  payload        JSONB NOT NULL,
  status_code    INT,
  response_body  TEXT,
  attempt_count  INT NOT NULL DEFAULT 0,
  delivered_at   TIMESTAMPTZ,
  next_retry_at  TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON webhook_deliveries (endpoint_id, created_at DESC);
ALTER TABLE webhook_deliveries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "deliveries_org" ON webhook_deliveries FOR ALL
  USING (endpoint_id IN (
    SELECT we.id FROM webhook_endpoints we
    JOIN profiles p ON p.organization_id = we.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- AI configuration (one row per workspace)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_configs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id    UUID NOT NULL UNIQUE REFERENCES workspaces ON DELETE CASCADE,
  enabled         BOOLEAN NOT NULL DEFAULT false,
  system_prompt   TEXT,
  model           TEXT NOT NULL DEFAULT 'gpt-4o-mini',
  temperature     FLOAT NOT NULL DEFAULT 0.7,
  max_tokens      INT NOT NULL DEFAULT 300,
  knowledge_base  TEXT,
  fallback_message TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE ai_configs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ai_configs_org" ON ai_configs FOR ALL
  USING (workspace_id IN (
    SELECT w.id FROM workspaces w
    JOIN profiles p ON p.organization_id = w.organization_id
    WHERE p.id = auth.uid()
  ));

-- ────────────────────────────────────────────────────────────────────────────
-- OAuth state (CSRF protection, shared across channels)
-- ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS oauth_states (
  state          TEXT PRIMARY KEY,
  channel        TEXT NOT NULL,
  user_id        UUID REFERENCES auth.users ON DELETE CASCADE,
  redirect_after TEXT,
  expires_at     TIMESTAMPTZ NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Clean up expired states automatically (Phase 4 cron or just let it stay small)
ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;
CREATE POLICY "oauth_states_own" ON oauth_states FOR ALL
  USING (user_id = auth.uid());
