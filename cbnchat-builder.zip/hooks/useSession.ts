/**
 * hooks/useSession.ts
 * Thin session hook. Returns the current user.
 *
 * Phase 1: returns demo user when DEMO_MODE=true.
 * TODO(Phase 4): Replace demo branch with real Supabase Auth session:
 *   const { data: { session } } = await supabase.auth.getSession()
 */

import { DEMO_MODE, demoUser } from '@/lib/demo/session'

export interface SessionUser {
  id: string
  email: string
  full_name: string
  avatar_url: string
  role: 'owner' | 'admin' | 'editor' | 'viewer'
  organization_id: string
}

export function useSession(): {
  user: SessionUser | null
  isAuthenticated: boolean
  isLoading: boolean
} {
  if (DEMO_MODE) {
    // TODO(Phase 4): Replace with real Supabase Auth before production deploy
    return { user: demoUser, isAuthenticated: true, isLoading: false }
  }

  // Fallback: check Zustand store (supports email/password sign-in stub)
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem('cbnchat-app-state')
      if (raw) {
        const state = JSON.parse(raw) as { state?: { isAuthenticated?: boolean; user?: SessionUser } }
        const s = state?.state
        if (s?.isAuthenticated && s?.user) {
          return { user: s.user, isAuthenticated: true, isLoading: false }
        }
      }
    } catch {
      // ignore parse errors
    }
  }

  return { user: null, isAuthenticated: false, isLoading: false }
}
