'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import {
  Home,
  Workflow,
  Sparkles,
  Inbox,
  Users,
  Send,
  Settings,
  MessageCircle,
  HelpCircle,
  LogOut,
  ChevronLeft,
  ChevronRight,
  User,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/lib/store'
import { WorkspaceSwitcher } from './workspace-switcher'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'

// DEMO: inbox has 1 unread message
const NAV_ITEMS: Array<{
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: number
}> = [
  { href: '/app/home', label: 'Home', icon: Home },
  { href: '/app/automation', label: 'Automations', icon: Workflow },
  { href: '/app/ai', label: 'AI', icon: Sparkles },
  { href: '/app/inbox', label: 'Inbox', icon: Inbox, badge: 1 },
  { href: '/app/contacts', label: 'Contacts', icon: Users },
  { href: '/app/broadcasts', label: 'Broadcasts', icon: Send },
  { href: '/app/settings/general', label: 'Settings', icon: Settings },
]

function NavItem({
  href,
  label,
  icon: Icon,
  collapsed,
  active,
  badge,
}: {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  collapsed: boolean
  active: boolean
  badge?: number
}) {
  const item = (
    <Link
      href={href}
      className={cn(
        'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors relative',
        collapsed ? 'justify-center px-0 w-10 h-10 mx-auto' : '',
        active
          ? 'bg-teal-50 text-teal-700 font-medium border-l-[3px] border-teal-600 rounded-l-none'
          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
      )}
    >
      <Icon className={cn('flex-shrink-0', collapsed ? 'w-5 h-5' : 'w-4 h-4')} />
      {!collapsed && <span className="flex-1">{label}</span>}
      {!collapsed && badge !== undefined && badge > 0 && (
        <span className="ml-auto flex h-4 min-w-4 items-center justify-center rounded-full bg-teal-600 px-1 text-[10px] font-bold text-white">
          {badge}
        </span>
      )}
      {collapsed && badge !== undefined && badge > 0 && (
        <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-teal-600 border border-white" />
      )}
    </Link>
  )

  if (collapsed) {
    return (
      <TooltipProvider delayDuration={0}>
        <Tooltip>
          <TooltipTrigger asChild>{item}</TooltipTrigger>
          <TooltipContent side="right" className="text-xs font-medium">
            {label}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return item
}

export function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { sidebarCollapsed, toggleSidebar, user, logout } = useAppStore((s) => ({
    sidebarCollapsed: s.sidebarCollapsed,
    toggleSidebar: s.toggleSidebar,
    user: s.user,
    logout: s.logout,
  }))

  function handleLogout() {
    logout()
    router.push('/login')
  }

  const collapsed = sidebarCollapsed

  return (
    <aside
      className={cn(
        'h-full bg-white border-r border-slate-200 flex flex-col flex-shrink-0 transition-all duration-200 relative',
        collapsed ? 'w-[72px]' : 'w-[240px]'
      )}
    >
      {/* Logo */}
      <div className={cn('flex items-center h-16 px-4 border-b border-slate-200 flex-shrink-0', collapsed ? 'justify-center' : 'gap-2')}>
        <div className="w-8 h-8 rounded-lg bg-teal-700 flex items-center justify-center flex-shrink-0">
          <MessageCircle className="w-4 h-4 text-white" />
        </div>
        {!collapsed && (
          <span className="font-bold text-slate-900 text-base tracking-tight">CBNchat</span>
        )}
      </div>

      {/* Workspace switcher */}
      <div className={cn('px-3 pt-3 pb-2 border-b border-slate-100', collapsed && 'px-1')}>
        <WorkspaceSwitcher collapsed={collapsed} />
      </div>

      {/* Navigation */}
      <nav className={cn('flex-1 overflow-y-auto py-3 space-y-0.5', collapsed ? 'px-1' : 'px-3')}>
        {NAV_ITEMS.map((item) => (
          <NavItem
            key={item.href}
            href={item.href}
            label={item.label}
            icon={item.icon}
            badge={item.badge}
            collapsed={collapsed}
            active={pathname === item.href || (item.href !== '/app/home' && pathname.startsWith(item.href))}
          />
        ))}
      </nav>

      {/* Bottom section */}
      <div className={cn('border-t border-slate-100 py-3 space-y-1', collapsed ? 'px-1' : 'px-3')}>
        {/* Help callout */}
        {!collapsed && (
          <div className="bg-slate-50 rounded-xl p-3 mb-3">
            <div className="flex items-center gap-2 mb-1">
              <HelpCircle className="w-4 h-4 text-teal-600" />
              <span className="text-xs font-semibold text-slate-700">Need Help?</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Check our docs or contact support.
            </p>
            <a
              href="mailto:support@cbnchat.local"
              className="mt-2 block text-xs text-teal-700 font-medium hover:underline"
            >
              Contact Support
            </a>
          </div>
        )}

        {/* User profile */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className={cn(
                'w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors text-left',
                collapsed ? 'justify-center px-0' : ''
              )}
            >
              <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-teal-700" />
              </div>
              {!collapsed && (
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate leading-tight">
                    {user?.full_name ?? 'Demo Admin'}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{user?.email ?? ''}</p>
                </div>
              )}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-48 rounded-xl" side="right" align="end" sideOffset={8}>
            <DropdownMenuItem asChild>
              <Link href="/app/settings/general" className="flex items-center gap-2 cursor-pointer">
                <Settings className="w-4 h-4" />
                Settings
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-red-600 flex items-center gap-2 cursor-pointer"
              onSelect={handleLogout}
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Collapse toggle — anchored to the right edge of the sidebar */}
      <button
        onClick={toggleSidebar}
        className="absolute -right-3 top-[72px] w-6 h-6 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center hover:bg-slate-50 transition-colors z-20"
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? (
          <ChevronRight className="w-3 h-3 text-slate-500" />
        ) : (
          <ChevronLeft className="w-3 h-3 text-slate-500" />
        )}
      </button>
    </aside>
  )
}
