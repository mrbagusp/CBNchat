'use client'

/**
 * DemoModeBanner — always renders on the server so there is no layout shift.
 * User can dismiss it; state stored in sessionStorage.
 * TODO(Phase 4): Remove this component before production deploy.
 */

import { useState } from 'react'
import { X } from 'lucide-react'

export function DemoModeBanner() {
  // Start VISIBLE — this component only renders inside the /app/* shell which
  // is already client-only (AppShell). No SSR hydration mismatch possible here.
  const [dismissed, setDismissed] = useState(false)

  if (dismissed) return null

  return (
    <div
      className="flex-shrink-0 relative flex items-center justify-center px-4 py-1.5 text-center text-xs font-medium text-white z-50"
      style={{ background: '#F59E0B' }}
    >
      {/* TODO(Phase 4): Replace with real Supabase Auth before production deploy */}
      DEMO MODE — Auth bypassed, using mock data. Real authentication activates in Phase 4.
      <button
        onClick={() => setDismissed(true)}
        className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center rounded hover:opacity-75 transition-opacity"
        aria-label="Dismiss demo banner"
      >
        <X className="w-3 h-3" />
      </button>
    </div>
  )
}
