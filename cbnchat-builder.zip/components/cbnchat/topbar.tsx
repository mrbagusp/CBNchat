'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { ChevronRight, Bell, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

// Maps path segments to human-readable labels
const SEGMENT_LABELS: Record<string, string> = {
  app: 'App',
  home: 'Home',
  'instagram-dm': 'Instagram DM',
  dashboard: 'Dashboard',
  automation: 'Automations',
  ai: 'AI',
  inbox: 'Inbox',
  contacts: 'Contacts',
  broadcasts: 'Broadcasts',
  settings: 'Settings',
  general: 'General',
  team: 'Team',
  workspaces: 'Workspaces',
  integrations: 'Integrations',
  webhooks: 'Webhooks',
  billing: 'Billing',
}

// Page-specific CTAs for the topbar
const PAGE_ACTIONS: Record<string, React.ReactNode> = {
  '/app/automation': (
    <Link href="/app/automation/new">
      <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg h-8 text-xs px-3">
        + New Automation
      </Button>
    </Link>
  ),
  '/app/contacts': (
    <Button size="sm" variant="outline" className="rounded-lg h-8 text-xs px-3 border-slate-200">
      Export CSV
    </Button>
  ),
  '/app/broadcasts': (
    <Button size="sm" className="bg-teal-700 hover:bg-teal-800 text-white rounded-lg h-8 text-xs px-3">
      + New Broadcast
    </Button>
  ),
}

export function Topbar() {
  const pathname = usePathname()

  // Build breadcrumb from current path
  const segments = pathname.split('/').filter(Boolean)
  const crumbs = segments.map((seg, i) => ({
    label: SEGMENT_LABELS[seg] ?? seg,
    href: '/' + segments.slice(0, i + 1).join('/'),
    isLast: i === segments.length - 1,
  }))

  // Filter out 'App' from display (too generic)
  const displayCrumbs = crumbs.filter((c) => c.label !== 'App')
  const pageTitle = displayCrumbs[displayCrumbs.length - 1]?.label ?? 'Home'
  const contextAction = PAGE_ACTIONS[pathname] ?? null

  return (
    <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 flex-shrink-0">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-sm">
        {displayCrumbs.map((crumb, i) => (
          <span key={crumb.href} className="flex items-center gap-1.5">
            {i < displayCrumbs.length - 1 ? (
              <>
                <Link
                  href={crumb.href}
                  className="text-slate-500 hover:text-slate-700 transition-colors"
                >
                  {crumb.label}
                </Link>
                <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              </>
            ) : (
              <span className="font-semibold text-slate-900">{crumb.label}</span>
            )}
          </span>
        ))}
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-2">
        {contextAction}
        <button className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors">
          <Search className="w-4 h-4" />
        </button>
        <button className="relative w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500 border-2 border-white" />
        </button>
      </div>
    </header>
  )
}
