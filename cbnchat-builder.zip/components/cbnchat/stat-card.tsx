'use client'

import { TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { ResponsiveContainer, LineChart, Line, Tooltip } from 'recharts'

interface StatCardProps {
  label: string
  value: number | string
  change?: number  // percent change, +/-
  sparkline?: number[]
  icon: React.ComponentType<{ className?: string }>
  iconBg: string
  iconColor: string
  suffix?: string
}

function formatValue(v: number | string) {
  if (typeof v === 'string') return v
  if (v >= 1000) return `${(v / 1000).toFixed(1)}k`
  return v.toString()
}

export function StatCard({ label, value, change, sparkline, icon: Icon, iconBg, iconColor, suffix }: StatCardProps) {
  const isPositive = (change ?? 0) > 0
  const isNeutral = change === 0 || change === undefined

  const chartData = sparkline?.map((v, i) => ({ i, v })) ?? []

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center', iconBg)}>
          <Icon className={cn('w-4 h-4', iconColor)} />
        </div>
        {change !== undefined && (
          <span
            className={cn(
              'flex items-center gap-0.5 text-xs font-semibold rounded-full px-2 py-0.5',
              isNeutral
                ? 'text-slate-500 bg-slate-100'
                : isPositive
                ? 'text-teal-700 bg-teal-50'
                : 'text-red-600 bg-red-50'
            )}
          >
            {isNeutral ? (
              <Minus className="w-3 h-3" />
            ) : isPositive ? (
              <TrendingUp className="w-3 h-3" />
            ) : (
              <TrendingDown className="w-3 h-3" />
            )}
            {isNeutral ? '—' : `${isPositive ? '+' : ''}${change?.toFixed(1)}%`}
          </span>
        )}
      </div>

      <div className="mb-3">
        <p className="text-2xl font-bold text-slate-900 tracking-tight">
          {formatValue(value)}
          {suffix && <span className="text-sm font-medium text-slate-500 ml-1">{suffix}</span>}
        </p>
        <p className="text-sm text-slate-500 mt-0.5">{label}</p>
      </div>

      {sparkline && sparkline.length > 0 && (
        <div className="h-10">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <Tooltip
                content={() => null}
              />
              <Line
                type="monotone"
                dataKey="v"
                stroke="#0F766E"
                strokeWidth={1.5}
                dot={false}
                activeDot={{ r: 3, fill: '#0F766E', stroke: 'white', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {change !== undefined && (
        <p className="text-xs text-slate-400 mt-1">vs. last 7 days</p>
      )}
    </div>
  )
}
