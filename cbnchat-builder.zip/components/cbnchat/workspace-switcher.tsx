'use client'

import { useState } from 'react'
import { ChevronDown, Check, Plus, Wifi, WifiOff, Instagram, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/lib/store'
import { WORKSPACES, type Workspace, type ChannelType } from '@/lib/mock-data'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Badge } from '@/components/ui/badge'
import { ChannelBadge } from './channel-badge'

// Facebook icon inline SVG
function FbIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073C24 5.404 18.627 0 12 0S0 5.404 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z" />
    </svg>
  )
}

const AVATAR_COLORS = [
  'bg-teal-600', 'bg-blue-600', 'bg-violet-600',
  'bg-pink-600', 'bg-orange-500', 'bg-emerald-600',
]

function WorkspaceAvatar({ ws, size = 'md' }: { ws: Workspace; size?: 'sm' | 'md' }) {
  const initials = ws.external_username.slice(0, 2).toUpperCase()
  const color = AVATAR_COLORS[ws.id.charCodeAt(3) % AVATAR_COLORS.length]
  const dim = size === 'sm' ? 'w-6 h-6 text-[10px]' : 'w-8 h-8 text-xs'
  return (
    <div className={cn('rounded-lg font-semibold text-white flex items-center justify-center flex-shrink-0', color, dim)}>
      {initials}
    </div>
  )
}

// Group workspaces by channel for section headers
function groupByChannel(workspaces: Workspace[]): Array<{ channel: ChannelType; items: Workspace[] }> {
  const map = new Map<ChannelType, Workspace[]>()
  for (const ws of workspaces) {
    if (!map.has(ws.channel)) map.set(ws.channel, [])
    map.get(ws.channel)!.push(ws)
  }
  return Array.from(map.entries()).map(([channel, items]) => ({ channel, items }))
}

const CHANNEL_SECTION_LABELS: Record<ChannelType, string> = {
  instagram: 'Instagram',
  facebook_page: 'Facebook Pages',
  tiktok: 'TikTok',
  whatsapp: 'WhatsApp',
}

export function WorkspaceSwitcher({ collapsed }: { collapsed: boolean }) {
  const activeWorkspaceId = useAppStore((s) => s.activeWorkspaceId)
  const setActiveWorkspaceId = useAppStore((s) => s.setActiveWorkspaceId)
  const activeWs = WORKSPACES.find((w) => w.id === activeWorkspaceId) ?? WORKSPACES[0]
  const groups = groupByChannel(WORKSPACES)
  const [connectOpen, setConnectOpen] = useState(false)

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            className={cn(
              'w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors text-left group border border-slate-200',
              collapsed && 'justify-center px-0 border-transparent',
            )}
          >
            <WorkspaceAvatar ws={activeWs} />
            {!collapsed && (
              <>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900 truncate leading-tight">
                    {activeWs.name}
                  </p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <ChannelBadge type={activeWs.channel} variant="dot" />
                    <span className="text-xs text-slate-400 truncate">@{activeWs.external_username}</span>
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 flex-shrink-0 group-hover:text-slate-600 transition-colors" />
              </>
            )}
          </button>
        </DropdownMenuTrigger>

        <DropdownMenuContent
          className="w-72 rounded-xl border border-slate-200 shadow-lg p-1"
          side="right"
          align="start"
          sideOffset={8}
        >
          {/* Instagram section */}
          <DropdownMenuLabel className="flex items-center gap-1.5 text-[10px] text-slate-400 font-semibold uppercase tracking-wider px-2 py-1.5">
            <Instagram className="w-3 h-3 text-pink-500" />
            Instagram
          </DropdownMenuLabel>
          {groups
            .filter((g) => g.channel === 'instagram')
            .flatMap((g) => g.items)
            .map((ws) => (
              <DropdownMenuItem
                key={ws.id}
                className={cn(
                  'flex items-center gap-2.5 px-2 py-2 rounded-lg cursor-pointer',
                  ws.id === activeWorkspaceId && 'bg-teal-50',
                )}
                onSelect={() => setActiveWorkspaceId(ws.id)}
              >
                <WorkspaceAvatar ws={ws} size="sm" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">{ws.name}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    {ws.status === 'connected'
                      ? <Wifi className="w-2.5 h-2.5 text-teal-500" />
                      : <WifiOff className="w-2.5 h-2.5 text-slate-300" />
                    }
                    <span className="text-xs text-slate-400 truncate">@{ws.external_username}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {ws.plan === 'pro' && (
                    <Badge className="h-4 px-1.5 text-[10px] bg-amber-100 text-amber-700 border-0 hover:bg-amber-100">
                      PRO
                    </Badge>
                  )}
                  {ws.id === activeWorkspaceId && (
                    <Check className="w-3.5 h-3.5 text-teal-600" />
                  )}
                </div>
              </DropdownMenuItem>
            ))}

          {/* Facebook section — no accounts yet */}
          <DropdownMenuSeparator className="my-1" />
          <DropdownMenuLabel className="flex items-center gap-1.5 text-[10px] text-slate-400 font-semibold uppercase tracking-wider px-2 py-1.5">
            <FbIcon className="w-3 h-3 text-blue-500" />
            Facebook
          </DropdownMenuLabel>
          <div className="px-2 py-2">
            <p className="text-xs text-slate-400 italic">No Facebook Pages connected yet</p>
          </div>

          {/* Connect New Account */}
          <DropdownMenuSeparator className="my-1" />
          <DropdownMenuItem
            className="flex items-center gap-2.5 px-2 py-2 rounded-lg text-teal-700 cursor-pointer hover:bg-teal-50 focus:bg-teal-50"
            onSelect={() => setConnectOpen(true)}
          >
            <div className="w-6 h-6 rounded-md border-2 border-dashed border-teal-300 flex items-center justify-center">
              <Plus className="w-3 h-3" />
            </div>
            <div>
              <p className="text-sm font-medium">+ Connect New Account</p>
              <p className="text-[11px] text-slate-400">Instagram · Facebook · more</p>
            </div>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Connect Account Modal */}
      {connectOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-bold text-slate-900 text-lg">Connect a New Account</h2>
              <button
                onClick={() => setConnectOpen(false)}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-slate-600 mb-5">
              Choose which platform to connect. Facebook Pages support is coming in Phase 7.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {/* Instagram — enabled */}
              <button
                onClick={() => setConnectOpen(false)}
                className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-pink-200 bg-pink-50 hover:border-pink-400 hover:bg-pink-100 transition-colors group"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-pink-500 flex items-center justify-center shadow-sm">
                  <Instagram className="w-6 h-6 text-white" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold text-slate-900">Instagram</p>
                  <p className="text-xs text-pink-600 font-medium mt-0.5">Continue with Instagram</p>
                </div>
              </button>

              {/* Facebook — disabled */}
              <div className="relative flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-slate-200 bg-slate-50 cursor-not-allowed opacity-60">
                <div className="w-12 h-12 rounded-xl bg-[#1877F2] flex items-center justify-center shadow-sm">
                  <FbIcon className="w-6 h-6 text-white" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold text-slate-900">Facebook</p>
                  <p className="text-xs text-slate-400 mt-0.5">Facebook Pages</p>
                </div>
                {/* Coming Soon overlay */}
                <div className="absolute inset-0 flex items-center justify-center rounded-xl">
                  <span className="bg-slate-800/80 text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                    Coming in Phase 7
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
