/**
 * components/cbnchat/channel-badge.tsx
 * Renders a small pill badge with the channel brand color + icon + label.
 * Used wherever a workspace or message needs a channel indicator.
 * Adding a new channel only requires adding a new entry to CHANNEL_META.
 */

import { cn } from '@/lib/utils'
import type { ChannelType } from '@/lib/mock-data'

interface ChannelMeta {
  label: string
  bg: string
  text: string
  dot: string
  icon: React.ReactNode
}

// Inline SVG icons keep this component dependency-free from lucide
function IgIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
    </svg>
  )
}

function FbIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
      <path d="M24 12.073C24 5.404 18.627 0 12 0S0 5.404 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z" />
    </svg>
  )
}

const CHANNEL_META: Record<ChannelType, ChannelMeta> = {
  instagram: {
    label: 'Instagram',
    bg: 'bg-pink-50',
    text: 'text-pink-700',
    dot: 'bg-pink-500',
    icon: <IgIcon />,
  },
  facebook_page: {
    label: 'Facebook',
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    dot: 'bg-blue-500',
    icon: <FbIcon />,
  },
  tiktok: {
    label: 'TikTok',
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    dot: 'bg-slate-500',
    icon: <span className="text-[10px] font-bold">TT</span>,
  },
  whatsapp: {
    label: 'WhatsApp',
    bg: 'bg-green-50',
    text: 'text-green-700',
    dot: 'bg-green-500',
    icon: <span className="text-[10px] font-bold">WA</span>,
  },
}

interface ChannelBadgeProps {
  type: ChannelType
  /** 'pill' shows icon + label; 'dot' shows just a coloured dot */
  variant?: 'pill' | 'dot' | 'icon'
  className?: string
}

export function ChannelBadge({ type, variant = 'pill', className }: ChannelBadgeProps) {
  const meta = CHANNEL_META[type] ?? CHANNEL_META.instagram

  if (variant === 'dot') {
    return (
      <span
        className={cn('inline-block w-2 h-2 rounded-full flex-shrink-0', meta.dot, className)}
        title={meta.label}
      />
    )
  }

  if (variant === 'icon') {
    return (
      <span
        className={cn(
          'inline-flex items-center justify-center w-5 h-5 rounded-full flex-shrink-0',
          meta.bg,
          meta.text,
          className,
        )}
        title={meta.label}
      >
        {meta.icon}
      </span>
    )
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium flex-shrink-0',
        meta.bg,
        meta.text,
        className,
      )}
    >
      {meta.icon}
      {meta.label}
    </span>
  )
}
