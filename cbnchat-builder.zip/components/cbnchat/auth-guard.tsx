'use client'

// TODO(Phase 4): Replace this stub with a real Supabase session guard.
// In demo mode auth is bypassed — this component is a no-op passthrough.
export function AuthGuard({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
  }, []) // run once on mount only

  // Always render children immediately — no redirect, no blank screen.
  // TODO(Phase 4): Show spinner while checking real session.
  return <>{children}</>
}
