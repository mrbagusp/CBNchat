'use client'

import { Sidebar } from '@/components/cbnchat/sidebar'
import { Topbar } from '@/components/cbnchat/topbar'
import { DemoModeBanner } from '@/components/cbnchat/demo-banner'

// AppShell is the single 'use client' boundary for the entire /app/* route tree.
// The layout.tsx is a Server Component that just renders this.
// TODO(Phase 4): Add real session guard here before production deploy.
export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col h-screen overflow-hidden" style={{ background: '#f8fafc' }}>
      <DemoModeBanner />
      <div className="flex flex-1 overflow-hidden min-h-0">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden min-w-0">
          <Topbar />
          <main className="flex-1 overflow-y-auto" style={{ background: '#f8fafc' }}>
            {children}
          </main>
        </div>
      </div>
    </div>
  )
}
