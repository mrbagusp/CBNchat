'use client'

import { usePathname } from 'next/navigation'
import { useAppStore } from '@/lib/store'
import { WORKSPACES } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

const PAGE_TITLES: Record<string, string> = {
  '/app/home':        'Dashboard',
  '/app/automation':  'Automations',
  '/app/ai':          'AI Configuration',
  '/app/inbox':       'Inbox',
  '/app/contacts':    'Contacts',
  '/app/broadcasts':  'Broadcasts',
  '/app/settings':    'Settings',
}

interface AppTopBarProps {
  /** Slot for contextual action buttons on the right side */
  actions?: React.ReactNode
}

export function AppTopBar({ actions }: AppTopBarProps) {
  const pathname = usePathname()
  const { activeWorkspaceId, sidebarCollapsed } = useAppStore()
  const activeWs = WORKSPACES.find((w) => w.id === activeWorkspaceId)

  // Derive segments for breadcrumb
  const segments = pathname.split('/').filter(Boolean)
  const pageTitle = PAGE_TITLES[pathname] ?? segments[segments.length - 1] ?? 'App'

  return (
    <header
      className={cn(
        'fixed top-0 right-0 h-14 bg-white border-b border-slate-200 flex items-center justify-between px-5 z-20 transition-all duration-200',
        sidebarCollapsed ? 'left-[72px]' : 'left-[240px]'
      )}
    >
      {/* Left: breadcrumb */}
      <div className="flex items-center gap-2 min-w-0">
        <span className="text-xs text-slate-400 hidden sm:block truncate">
          {activeWs?.name ?? 'CBNchat'}
        </span>
        <span className="text-slate-300 hidden sm:block" aria-hidden="true">/</span>
        <h1 className="text-sm font-semibold text-slate-900 truncate">{pageTitle}</h1>
      </div>

      {/* Right: contextual actions slot */}
      {actions && (
        <div className="flex items-center gap-2">
          {actions}
        </div>
      )}
    </header>
  )
}
