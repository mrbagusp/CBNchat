import Link from 'next/link'
import { MessageCircle } from 'lucide-react'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-slate-200 py-4">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-6">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-700">
              <MessageCircle className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold text-slate-900">CBNchat</span>
          </Link>
        </div>
      </header>
      <main className="mx-auto max-w-3xl px-6 py-12">
        <h1 className="mb-2 text-3xl font-bold text-slate-900">Privacy Policy</h1>
        <p className="mb-8 text-sm text-slate-400">Last updated: April 2026</p>
        <div className="prose prose-slate max-w-none text-slate-700 text-sm leading-relaxed space-y-4">
          <p>CBNchat (&quot;we&quot;, &quot;our&quot;, &quot;us&quot;) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard information when you use our service.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Data We Collect</h2>
          <p>We collect information you provide directly (account details, workspace configurations) and data generated through your connected Instagram or Facebook accounts (comments, DM metadata, follower counts) solely to provide the automation service.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">How We Use Data</h2>
          <p>We use your data to run automations, deliver messages on your behalf, and generate analytics. We do not sell or share your data with third parties for advertising purposes.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Instagram API Compliance</h2>
          <p>CBNchat uses the official Instagram Graph API. All data handling complies with Meta&apos;s Platform Terms and Privacy Policy.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Contact</h2>
          <p>For privacy inquiries, contact us at <a href="mailto:privacy@cbnchat.local" className="text-teal-700 hover:underline">privacy@cbnchat.local</a>.</p>
        </div>
      </main>
    </div>
  )
}
