import { Radio } from 'lucide-react'
import { StubPage } from '@/components/cbnchat/stub-page'

export default function BroadcastsPage() {
  return (
    <StubPage
      icon={Radio}
      title="Broadcasts"
      phase="6"
      description="Schedule and send mass DM campaigns to segmented contact lists with delivery tracking."
    />
  )
}
