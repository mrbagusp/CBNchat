import { Inbox } from 'lucide-react'
import { StubPage } from '@/components/cbnchat/stub-page'

export default function InboxPage() {
  return (
    <StubPage
      icon={Inbox}
      title="Inbox"
      phase="6"
      description="A unified inbox for all Instagram DMs and comments across your connected accounts."
    />
  )
}
