import Link from 'next/link'
import { MessageCircle } from 'lucide-react'

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-slate-200 py-4">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-6">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-700">
              <MessageCircle className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold text-slate-900">CBNchat</span>
          </Link>
        </div>
      </header>
      <main className="mx-auto max-w-3xl px-6 py-12">
        <h1 className="mb-2 text-3xl font-bold text-slate-900">Terms of Service</h1>
        <p className="mb-8 text-sm text-slate-400">Last updated: April 2026</p>
        <div className="text-slate-700 text-sm leading-relaxed space-y-4">
          <p>By using CBNchat, you agree to these Terms of Service. Please read them carefully.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Acceptable Use</h2>
          <p>You may only use CBNchat for lawful purposes and in compliance with Meta&apos;s Platform Policies. You may not use CBNchat to send spam, harass users, or violate any applicable laws.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Account Responsibility</h2>
          <p>You are responsible for maintaining the security of your account credentials and for all activity that occurs under your account.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Service Availability</h2>
          <p>We strive for 99.9% uptime but do not guarantee uninterrupted service. Scheduled maintenance will be communicated in advance.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Termination</h2>
          <p>We reserve the right to suspend or terminate accounts that violate these terms without prior notice.</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-6">Contact</h2>
          <p>For terms inquiries, contact <a href="mailto:legal@cbnchat.local" className="text-teal-700 hover:underline">legal@cbnchat.local</a>.</p>
        </div>
      </main>
    </div>
  )
}
