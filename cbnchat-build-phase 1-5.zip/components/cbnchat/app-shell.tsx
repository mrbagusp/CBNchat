'use client'

import { X, AlertTriangle } from 'lucide-react'
import { useState } from 'react'
import { Sidebar } from './sidebar'

export function AppShell({ children }: { children: React.ReactNode }) {
  const [demoBannerDismissed, setDemoBannerDismissed] = useState(false)

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-slate-50">
      {/* Demo mode banner */}
      {!demoBannerDismissed && (
        <div className="flex shrink-0 items-center justify-center gap-2 bg-amber-500 px-4 py-1.5 text-sm font-medium text-white">
          <AlertTriangle className="h-4 w-4" />
          <span>DEMO MODE — Auth bypassed, using mock data.</span>
          <button
            onClick={() => setDemoBannerDismissed(true)}
            aria-label="Dismiss demo banner"
            className="ml-2 rounded p-0.5 hover:bg-amber-400 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />

        {/* Content */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Topbar */}
          <header className="flex h-14 shrink-0 items-center border-b border-slate-200 bg-white px-6">
            <div className="flex-1" />
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-emerald-400" />
              <span className="text-xs font-medium text-slate-500">Live</span>
            </div>
          </header>

          {/* Page content — children can escape padding with -m-6 for full-height views */}
          <main className="relative flex-1 overflow-hidden min-h-0">
            <div className="h-full overflow-y-auto">
              <div className="mx-auto max-w-7xl p-6 min-h-full">
                {children}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
